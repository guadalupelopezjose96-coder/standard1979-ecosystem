--
-- PostgreSQL database cluster dump
--

\restrict zgRbI8KuldXZ2secy18flFu1ugu45PZV5btD6ze1mXEhTVi5dG2zQxOsk2x86pC

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE aaufsa_app_user;
ALTER ROLE aaufsa_app_user WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE app_user;
ALTER ROLE app_user WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE test_user;
ALTER ROLE test_user WITH SUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:g+G9cnVLWJJIBcSXMfseAg==$Yfehrxe7h9nCXrjWnAfQ7InKe63oRW6kyXdzq0zaonk=:Obz+jrJjp//97Rhb+guH8jDWjDU6X1z1xHRRqA9hv6c=';
CREATE ROLE u0_a315;
ALTER ROLE u0_a315 WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS;

--
-- User Configurations
--








\unrestrict zgRbI8KuldXZ2secy18flFu1ugu45PZV5btD6ze1mXEhTVi5dG2zQxOsk2x86pC

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict lZgAXhAc43DD5WoCvMnb7bqb1KBywSGqH8moibsEu577sByJo7Iq60s4mSgCvvS

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict lZgAXhAc43DD5WoCvMnb7bqb1KBywSGqH8moibsEu577sByJo7Iq60s4mSgCvvS

--
-- Database "aaufs_ledger" dump
--

--
-- PostgreSQL database dump
--

\restrict mGyRargJixm2NEUZJJ0Lk7iQOSqroVLCmSz4UHAHrWpOjtLi3gtbaedkmuohSVC

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: aaufs_ledger; Type: DATABASE; Schema: -; Owner: u0_a315
--

CREATE DATABASE aaufs_ledger WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE aaufs_ledger OWNER TO u0_a315;

\unrestrict mGyRargJixm2NEUZJJ0Lk7iQOSqroVLCmSz4UHAHrWpOjtLi3gtbaedkmuohSVC
\connect aaufs_ledger
\restrict mGyRargJixm2NEUZJJ0Lk7iQOSqroVLCmSz4UHAHrWpOjtLi3gtbaedkmuohSVC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: fiscal_aaufsa; Type: SCHEMA; Schema: -; Owner: u0_a315
--

CREATE SCHEMA fiscal_aaufsa;


ALTER SCHEMA fiscal_aaufsa OWNER TO u0_a315;

--
-- Name: ledger_core; Type: SCHEMA; Schema: -; Owner: u0_a315
--

CREATE SCHEMA ledger_core;


ALTER SCHEMA ledger_core OWNER TO u0_a315;

--
-- Name: fn_enforce_zero_sum_balance(); Type: FUNCTION; Schema: ledger_core; Owner: u0_a315
--

CREATE FUNCTION ledger_core.fn_enforce_zero_sum_balance() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_sum_debit NUMERIC(20, 0);
    v_sum_credit NUMERIC(20, 0);
BEGIN
    SELECT COALESCE(SUM(debit_cents), 0), COALESCE(SUM(credit_cents), 0)
    INTO v_sum_debit, v_sum_credit
    FROM ledger_core.journal_entries
    WHERE batch_id = NEW.batch_id;

    IF v_sum_debit <> v_sum_credit THEN
        RAISE EXCEPTION 'ZERO_SUM_INVARIANT_VIOLATION: Batch % Debits (%) != Credits (%)',
            NEW.batch_id, v_sum_debit, v_sum_credit;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION ledger_core.fn_enforce_zero_sum_balance() OWNER TO u0_a315;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: assessments; Type: TABLE; Schema: fiscal_aaufsa; Owner: u0_a315
--

CREATE TABLE fiscal_aaufsa.assessments (
    assessment_id uuid DEFAULT gen_random_uuid() NOT NULL,
    domain_id bigint NOT NULL,
    employee_id bigint NOT NULL,
    reference_wage_cents numeric(20,0) NOT NULL,
    tax_15_3_cents numeric(20,0) NOT NULL,
    social_sec_75_cents numeric(20,0) NOT NULL,
    reskilling_25_cents numeric(20,0) NOT NULL,
    is_clawback boolean DEFAULT false NOT NULL,
    certified_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT chk_aaufsa_distribution_balance CHECK ((tax_15_3_cents = (social_sec_75_cents + reskilling_25_cents)))
);


ALTER TABLE fiscal_aaufsa.assessments OWNER TO u0_a315;

--
-- Name: v_fiduciary_remittance_summary; Type: VIEW; Schema: fiscal_aaufsa; Owner: u0_a315
--

CREATE VIEW fiscal_aaufsa.v_fiduciary_remittance_summary AS
 SELECT domain_id,
    count(assessment_id) AS total_displacements,
    sum(reference_wage_cents) AS total_base_wages_cents,
    sum(tax_15_3_cents) AS total_aaufsa_tax_cents,
    sum(social_sec_75_cents) AS total_oasi_di_fiduciary_cents,
    sum(reskilling_25_cents) AS total_reskilling_fund_cents
   FROM fiscal_aaufsa.assessments
  GROUP BY domain_id;


ALTER VIEW fiscal_aaufsa.v_fiduciary_remittance_summary OWNER TO u0_a315;

--
-- Name: journal_batches; Type: TABLE; Schema: ledger_core; Owner: u0_a315
--

CREATE TABLE ledger_core.journal_batches (
    batch_id uuid DEFAULT gen_random_uuid() NOT NULL,
    domain_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    description text NOT NULL,
    total_amount_cents numeric(20,0) NOT NULL,
    CONSTRAINT chk_domain_valid CHECK ((domain_id = ANY (ARRAY['877771073297'::bigint, '964521086569'::bigint, '188680247367'::bigint, '1087754464927'::bigint, '282230018778'::bigint, (358233233)::bigint])))
);

ALTER TABLE ONLY ledger_core.journal_batches FORCE ROW LEVEL SECURITY;


ALTER TABLE ledger_core.journal_batches OWNER TO u0_a315;

--
-- Name: journal_entries; Type: TABLE; Schema: ledger_core; Owner: u0_a315
--

CREATE TABLE ledger_core.journal_entries (
    entry_id uuid DEFAULT gen_random_uuid() NOT NULL,
    batch_id uuid NOT NULL,
    domain_id bigint NOT NULL,
    account_code character varying(64) NOT NULL,
    debit_cents numeric(20,0) DEFAULT 0 NOT NULL,
    credit_cents numeric(20,0) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT chk_exclusive_debit_credit CHECK ((((debit_cents > (0)::numeric) AND (credit_cents = (0)::numeric)) OR ((credit_cents > (0)::numeric) AND (debit_cents = (0)::numeric)))),
    CONSTRAINT chk_non_negative_entries CHECK (((debit_cents >= (0)::numeric) AND (credit_cents >= (0)::numeric)))
);

ALTER TABLE ONLY ledger_core.journal_entries FORCE ROW LEVEL SECURITY;


ALTER TABLE ledger_core.journal_entries OWNER TO u0_a315;

--
-- Data for Name: assessments; Type: TABLE DATA; Schema: fiscal_aaufsa; Owner: u0_a315
--

COPY fiscal_aaufsa.assessments (assessment_id, domain_id, employee_id, reference_wage_cents, tax_15_3_cents, social_sec_75_cents, reskilling_25_cents, is_clawback, certified_at) FROM stdin;
\.


--
-- Data for Name: journal_batches; Type: TABLE DATA; Schema: ledger_core; Owner: u0_a315
--

COPY ledger_core.journal_batches (batch_id, domain_id, created_at, description, total_amount_cents) FROM stdin;
c83301fb-4e8e-4f8f-8097-de4f3c77143d	877771073297	2026-10-29 21:44:17.376199-04	BATCH_VPP_001	500000
20e781b7-c877-4bca-be52-6848970ff8de	877771073297	2026-10-29 21:45:11.330175-04	BATCH_VPP_001	500000
e41d2b98-bace-48f7-ba6e-fd90330955f0	877771073297	2026-10-29 21:46:00.96269-04	BATCH_VPP_001	500000
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: ledger_core; Owner: u0_a315
--

COPY ledger_core.journal_entries (entry_id, batch_id, domain_id, account_code, debit_cents, credit_cents, created_at) FROM stdin;
5470aebb-2857-4b82-9652-12dcd7ab161f	c83301fb-4e8e-4f8f-8097-de4f3c77143d	877771073297	ASSET_CASH	500000	0	2026-10-29 21:44:17.376996-04
ce51f2fc-b89d-4250-9a42-c02780465692	c83301fb-4e8e-4f8f-8097-de4f3c77143d	877771073297	EQUITY_CAPITAL	0	500000	2026-10-29 21:44:17.377723-04
8b700c24-0d54-4cc8-a257-26c9f5c27de6	20e781b7-c877-4bca-be52-6848970ff8de	877771073297	ASSET_CASH	500000	0	2026-10-29 21:45:11.330508-04
d8a34282-7339-42e5-a51c-e471f812124a	20e781b7-c877-4bca-be52-6848970ff8de	877771073297	EQUITY_CAPITAL	0	500000	2026-10-29 21:45:11.330717-04
bba8fc4b-f9db-477b-a182-0e64b39aead0	e41d2b98-bace-48f7-ba6e-fd90330955f0	877771073297	ASSET_CASH	500000	0	2026-10-29 21:46:00.96324-04
9c28cd8b-db5e-46d2-85ad-9377d7aed962	e41d2b98-bace-48f7-ba6e-fd90330955f0	877771073297	EQUITY_CAPITAL	0	500000	2026-10-29 21:46:00.963588-04
\.


--
-- Name: assessments assessments_pkey; Type: CONSTRAINT; Schema: fiscal_aaufsa; Owner: u0_a315
--

ALTER TABLE ONLY fiscal_aaufsa.assessments
    ADD CONSTRAINT assessments_pkey PRIMARY KEY (assessment_id);


--
-- Name: journal_batches journal_batches_pkey; Type: CONSTRAINT; Schema: ledger_core; Owner: u0_a315
--

ALTER TABLE ONLY ledger_core.journal_batches
    ADD CONSTRAINT journal_batches_pkey PRIMARY KEY (batch_id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: ledger_core; Owner: u0_a315
--

ALTER TABLE ONLY ledger_core.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (entry_id);


--
-- Name: assessments rule_no_delete_aaufsa_assessments; Type: RULE; Schema: fiscal_aaufsa; Owner: u0_a315
--

CREATE RULE rule_no_delete_aaufsa_assessments AS
    ON DELETE TO fiscal_aaufsa.assessments DO INSTEAD NOTHING;


--
-- Name: assessments rule_no_update_aaufsa_assessments; Type: RULE; Schema: fiscal_aaufsa; Owner: u0_a315
--

CREATE RULE rule_no_update_aaufsa_assessments AS
    ON UPDATE TO fiscal_aaufsa.assessments DO INSTEAD NOTHING;


--
-- Name: journal_batches rule_no_delete_journal_batches; Type: RULE; Schema: ledger_core; Owner: u0_a315
--

CREATE RULE rule_no_delete_journal_batches AS
    ON DELETE TO ledger_core.journal_batches DO INSTEAD NOTHING;


--
-- Name: journal_entries rule_no_delete_journal_entries; Type: RULE; Schema: ledger_core; Owner: u0_a315
--

CREATE RULE rule_no_delete_journal_entries AS
    ON DELETE TO ledger_core.journal_entries DO INSTEAD NOTHING;


--
-- Name: journal_batches rule_no_update_journal_batches; Type: RULE; Schema: ledger_core; Owner: u0_a315
--

CREATE RULE rule_no_update_journal_batches AS
    ON UPDATE TO ledger_core.journal_batches DO INSTEAD NOTHING;


--
-- Name: journal_entries rule_no_update_journal_entries; Type: RULE; Schema: ledger_core; Owner: u0_a315
--

CREATE RULE rule_no_update_journal_entries AS
    ON UPDATE TO ledger_core.journal_entries DO INSTEAD NOTHING;


--
-- Name: journal_entries trg_verify_batch_balance; Type: TRIGGER; Schema: ledger_core; Owner: u0_a315
--

CREATE CONSTRAINT TRIGGER trg_verify_batch_balance AFTER INSERT ON ledger_core.journal_entries DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION ledger_core.fn_enforce_zero_sum_balance();


--
-- Name: journal_entries journal_entries_batch_id_fkey; Type: FK CONSTRAINT; Schema: ledger_core; Owner: u0_a315
--

ALTER TABLE ONLY ledger_core.journal_entries
    ADD CONSTRAINT journal_entries_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES ledger_core.journal_batches(batch_id);


--
-- Name: journal_batches; Type: ROW SECURITY; Schema: ledger_core; Owner: u0_a315
--

ALTER TABLE ledger_core.journal_batches ENABLE ROW LEVEL SECURITY;

--
-- Name: journal_entries; Type: ROW SECURITY; Schema: ledger_core; Owner: u0_a315
--

ALTER TABLE ledger_core.journal_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: journal_batches policy_domain_isolation_batches; Type: POLICY; Schema: ledger_core; Owner: u0_a315
--

CREATE POLICY policy_domain_isolation_batches ON ledger_core.journal_batches AS RESTRICTIVE USING ((domain_id = (NULLIF(current_setting('app.current_domain_id'::text, true), ''::text))::bigint)) WITH CHECK ((domain_id = (NULLIF(current_setting('app.current_domain_id'::text, true), ''::text))::bigint));


--
-- Name: journal_entries policy_domain_isolation_entries; Type: POLICY; Schema: ledger_core; Owner: u0_a315
--

CREATE POLICY policy_domain_isolation_entries ON ledger_core.journal_entries AS RESTRICTIVE USING ((domain_id = (NULLIF(current_setting('app.current_domain_id'::text, true), ''::text))::bigint)) WITH CHECK ((domain_id = (NULLIF(current_setting('app.current_domain_id'::text, true), ''::text))::bigint));


--
-- Name: SCHEMA ledger_core; Type: ACL; Schema: -; Owner: u0_a315
--

GRANT USAGE ON SCHEMA ledger_core TO app_user;


--
-- Name: TABLE journal_batches; Type: ACL; Schema: ledger_core; Owner: u0_a315
--

GRANT SELECT,INSERT ON TABLE ledger_core.journal_batches TO app_user;


--
-- Name: TABLE journal_entries; Type: ACL; Schema: ledger_core; Owner: u0_a315
--

GRANT SELECT,INSERT ON TABLE ledger_core.journal_entries TO app_user;


--
-- PostgreSQL database dump complete
--

\unrestrict mGyRargJixm2NEUZJJ0Lk7iQOSqroVLCmSz4UHAHrWpOjtLi3gtbaedkmuohSVC

--
-- Database "app_test_db" dump
--

--
-- PostgreSQL database dump
--

\restrict xbBMv08KGNZjmvfIEQuuWSFlsmOD7YAQ8kQYkA4ItZcg6WS56O77DK6kihulb35

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: app_test_db; Type: DATABASE; Schema: -; Owner: test_user
--

CREATE DATABASE app_test_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE app_test_db OWNER TO test_user;

\unrestrict xbBMv08KGNZjmvfIEQuuWSFlsmOD7YAQ8kQYkA4ItZcg6WS56O77DK6kihulb35
\connect app_test_db
\restrict xbBMv08KGNZjmvfIEQuuWSFlsmOD7YAQ8kQYkA4ItZcg6WS56O77DK6kihulb35

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;


--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: entry_direction; Type: TYPE; Schema: public; Owner: test_user
--

CREATE TYPE public.entry_direction AS ENUM (
    'DEBIT',
    'CREDIT'
);


ALTER TYPE public.entry_direction OWNER TO test_user;

--
-- Name: verify_journal_entry_balance(); Type: FUNCTION; Schema: public; Owner: test_user
--

CREATE FUNCTION public.verify_journal_entry_balance() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_balance BIGINT;
    v_entry_id UUID;
BEGIN
    IF TG_OP = 'DELETE' THEN
        v_entry_id := OLD.journal_entry_id;
    ELSE
        v_entry_id := NEW.journal_entry_id;
    END IF;

    SELECT COALESCE(
        SUM(
            CASE 
                WHEN direction = 'DEBIT' THEN amount_cents 
                WHEN direction = 'CREDIT' THEN -amount_cents 
            END
        ), 0)
    INTO v_balance
    FROM ledger_lines
    WHERE journal_entry_id = v_entry_id;

    IF v_balance <> 0 THEN
        RAISE EXCEPTION 'Desbalance contable en el asiento %: suma neta es % centavos (debe ser 0)',
            v_entry_id, v_balance
            USING ERRCODE = 'check_violation';
    END IF;

    RETURN NULL;
END;
$$;


ALTER FUNCTION public.verify_journal_entry_balance() OWNER TO test_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounting_periods; Type: TABLE; Schema: public; Owner: test_user
--

CREATE TABLE public.accounting_periods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    period_name character varying(64) NOT NULL,
    validity_window tstzrange NOT NULL,
    is_closed boolean DEFAULT false NOT NULL
);


ALTER TABLE public.accounting_periods OWNER TO test_user;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: test_user
--

CREATE TABLE public.accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    account_number character varying(32) NOT NULL,
    name character varying(128) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


ALTER TABLE public.accounts OWNER TO test_user;

--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: test_user
--

CREATE TABLE public.journal_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    transaction_code character varying(64) NOT NULL,
    description text NOT NULL,
    posted_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    is_posted boolean DEFAULT true NOT NULL
);


ALTER TABLE public.journal_entries OWNER TO test_user;

--
-- Name: ledger_lines; Type: TABLE; Schema: public; Owner: test_user
--

CREATE TABLE public.ledger_lines (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    journal_entry_id uuid NOT NULL,
    account_id uuid NOT NULL,
    direction public.entry_direction NOT NULL,
    amount_cents bigint NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT ledger_lines_amount_cents_check CHECK ((amount_cents > 0))
);


ALTER TABLE public.ledger_lines OWNER TO test_user;

--
-- Data for Name: accounting_periods; Type: TABLE DATA; Schema: public; Owner: test_user
--

COPY public.accounting_periods (id, tenant_id, period_name, validity_window, is_closed) FROM stdin;
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: test_user
--

COPY public.accounts (id, tenant_id, account_number, name, currency, is_active, created_at) FROM stdin;
c38a289b-3a27-4ac5-b5ef-b6caaadc8e87	4516fdfc-9d95-4f28-b75f-102f683631ed	1001	Caja General	USD	t	2026-11-01 16:03:26.365724-05
320e1879-33ed-4a6f-b95e-6434416d0659	4516fdfc-9d95-4f28-b75f-102f683631ed	4001	Ingresos por Ventas	USD	t	2026-11-01 16:03:26.367156-05
ae5fc262-3ce8-4080-92a4-443005084320	59470a8b-27d3-402a-ba80-a94b13a9e3d8	1001	Caja General	USD	t	2026-11-01 16:07:56.618972-05
3d0e4e82-2044-47b1-9a2d-60c85ca08def	59470a8b-27d3-402a-ba80-a94b13a9e3d8	4001	Ingresos por Ventas	USD	t	2026-11-01 16:07:56.620526-05
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: test_user
--

COPY public.journal_entries (id, tenant_id, transaction_code, description, posted_at, is_posted) FROM stdin;
008d2901-a75a-40dc-a180-4c5f23964ac9	4516fdfc-9d95-4f28-b75f-102f683631ed	TX-e9c62898e9514625944b59ca94f471d4	Transacción contable de prueba	2026-11-01 16:03:26.433061-05	t
afc3d1ba-0ab4-4c76-b43e-6bf543823e8e	59470a8b-27d3-402a-ba80-a94b13a9e3d8	TX-12c5834f0bcc486abcaab0a3967f10ee	Transacción contable de prueba	2026-11-01 16:07:56.624288-05	t
\.


--
-- Data for Name: ledger_lines; Type: TABLE DATA; Schema: public; Owner: test_user
--

COPY public.ledger_lines (id, journal_entry_id, account_id, direction, amount_cents, created_at) FROM stdin;
8e6436f6-ca2d-4e5e-a1cc-e45f3df19d29	008d2901-a75a-40dc-a180-4c5f23964ac9	c38a289b-3a27-4ac5-b5ef-b6caaadc8e87	DEBIT	2500	2026-11-01 16:03:26.436812-05
ce44d848-7035-454f-a698-4f90ee06be33	008d2901-a75a-40dc-a180-4c5f23964ac9	320e1879-33ed-4a6f-b95e-6434416d0659	CREDIT	2500	2026-11-01 16:03:26.443541-05
832ae041-2523-482e-acd6-94d21eca58a4	afc3d1ba-0ab4-4c76-b43e-6bf543823e8e	ae5fc262-3ce8-4080-92a4-443005084320	DEBIT	2500	2026-11-01 16:07:56.62619-05
42085e69-25ac-4d62-9e7b-b09376e0eef5	afc3d1ba-0ab4-4c76-b43e-6bf543823e8e	3d0e4e82-2044-47b1-9a2d-60c85ca08def	CREDIT	2500	2026-11-01 16:07:56.628908-05
\.


--
-- Name: accounting_periods accounting_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: test_user
--

ALTER TABLE ONLY public.accounting_periods
    ADD CONSTRAINT accounting_periods_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: test_user
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: accounting_periods excl_overlapping_periods; Type: CONSTRAINT; Schema: public; Owner: test_user
--

ALTER TABLE ONLY public.accounting_periods
    ADD CONSTRAINT excl_overlapping_periods EXCLUDE USING gist (tenant_id WITH =, validity_window WITH &&);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: test_user
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_transaction_code_key; Type: CONSTRAINT; Schema: public; Owner: test_user
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_transaction_code_key UNIQUE (transaction_code);


--
-- Name: ledger_lines ledger_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: test_user
--

ALTER TABLE ONLY public.ledger_lines
    ADD CONSTRAINT ledger_lines_pkey PRIMARY KEY (id);


--
-- Name: accounts uq_tenant_account; Type: CONSTRAINT; Schema: public; Owner: test_user
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT uq_tenant_account UNIQUE (tenant_id, account_number);


--
-- Name: idx_ledger_lines_account; Type: INDEX; Schema: public; Owner: test_user
--

CREATE INDEX idx_ledger_lines_account ON public.ledger_lines USING btree (account_id);


--
-- Name: idx_ledger_lines_entry; Type: INDEX; Schema: public; Owner: test_user
--

CREATE INDEX idx_ledger_lines_entry ON public.ledger_lines USING btree (journal_entry_id);


--
-- Name: ledger_lines trg_enforce_double_entry_balance; Type: TRIGGER; Schema: public; Owner: test_user
--

CREATE CONSTRAINT TRIGGER trg_enforce_double_entry_balance AFTER INSERT OR DELETE OR UPDATE ON public.ledger_lines DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.verify_journal_entry_balance();


--
-- Name: ledger_lines ledger_lines_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: test_user
--

ALTER TABLE ONLY public.ledger_lines
    ADD CONSTRAINT ledger_lines_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE RESTRICT;


--
-- Name: ledger_lines ledger_lines_journal_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: test_user
--

ALTER TABLE ONLY public.ledger_lines
    ADD CONSTRAINT ledger_lines_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES public.journal_entries(id) ON DELETE RESTRICT;


--
-- Name: accounting_periods; Type: ROW SECURITY; Schema: public; Owner: test_user
--

ALTER TABLE public.accounting_periods ENABLE ROW LEVEL SECURITY;

--
-- Name: accounts; Type: ROW SECURITY; Schema: public; Owner: test_user
--

ALTER TABLE public.accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: journal_entries; Type: ROW SECURITY; Schema: public; Owner: test_user
--

ALTER TABLE public.journal_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: ledger_lines; Type: ROW SECURITY; Schema: public; Owner: test_user
--

ALTER TABLE public.ledger_lines ENABLE ROW LEVEL SECURITY;

--
-- Name: accounts tenant_isolation_accounts; Type: POLICY; Schema: public; Owner: test_user
--

CREATE POLICY tenant_isolation_accounts ON public.accounts USING ((tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid));


--
-- Name: journal_entries tenant_isolation_journal; Type: POLICY; Schema: public; Owner: test_user
--

CREATE POLICY tenant_isolation_journal ON public.journal_entries USING ((tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid));


--
-- Name: ledger_lines tenant_isolation_lines; Type: POLICY; Schema: public; Owner: test_user
--

CREATE POLICY tenant_isolation_lines ON public.ledger_lines USING ((journal_entry_id IN ( SELECT journal_entries.id
   FROM public.journal_entries
  WHERE (journal_entries.tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid))));


--
-- Name: accounting_periods tenant_isolation_periods; Type: POLICY; Schema: public; Owner: test_user
--

CREATE POLICY tenant_isolation_periods ON public.accounting_periods USING ((tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid));


--
-- PostgreSQL database dump complete
--

\unrestrict xbBMv08KGNZjmvfIEQuuWSFlsmOD7YAQ8kQYkA4ItZcg6WS56O77DK6kihulb35

--
-- Database "aura_ledger" dump
--

--
-- PostgreSQL database dump
--

\restrict 94mWxOT9nCODOk3cizpLuR8q3RoxaRfnfRbopzMHW6PJluwxN2BqJAXdNX6jKoN

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: aura_ledger; Type: DATABASE; Schema: -; Owner: u0_a315
--

CREATE DATABASE aura_ledger WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE aura_ledger OWNER TO u0_a315;

\unrestrict 94mWxOT9nCODOk3cizpLuR8q3RoxaRfnfRbopzMHW6PJluwxN2BqJAXdNX6jKoN
\connect aura_ledger
\restrict 94mWxOT9nCODOk3cizpLuR8q3RoxaRfnfRbopzMHW6PJluwxN2BqJAXdNX6jKoN

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: check_transaction_balance(); Type: FUNCTION; Schema: public; Owner: u0_a315
--

CREATE FUNCTION public.check_transaction_balance() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    total_debit BIGINT;
    total_credit BIGINT;
BEGIN
    SELECT COALESCE(SUM(debit_amount_cents), 0), COALESCE(SUM(credit_amount_cents), 0)
    INTO total_debit, total_credit
    FROM ledger_lines
    WHERE entry_id = NEW.entry_id;

    IF total_debit <> total_credit THEN
        RAISE EXCEPTION 'Violacion de partida doble para entry_id %: Debitos (%) <> Creditos (%)', 
            NEW.entry_id, total_debit, total_credit;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.check_transaction_balance() OWNER TO u0_a315;

--
-- Name: verify_energetics_double_entry_balance(); Type: FUNCTION; Schema: public; Owner: u0_a315
--

CREATE FUNCTION public.verify_energetics_double_entry_balance() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_total_debits BIGINT;
    v_total_credits BIGINT;
    v_line_count INT;
BEGIN
    SELECT
        COALESCE(SUM(debit_micro_usd), 0),
        COALESCE(SUM(credit_micro_usd), 0),
        COUNT(*)
    INTO v_total_debits, v_total_credits, v_line_count
    FROM energetics_settlement_lines
    WHERE entry_id = NEW.entry_id;

    IF v_line_count < 2 THEN
        RAISE EXCEPTION 'VIOLACION_PARTIDA_DOBLE: El asiento % requiere al menos 2 lineas contables.', NEW.entry_id;
    END IF;

    IF (v_total_debits - v_total_credits) <> 0 THEN
        RAISE EXCEPTION 'DESBALANCE_CONTABLE_ENERGETICO: Asiento % presenta Debitos (%) != Creditos (%). Delta debe ser 0.',
            NEW.entry_id, v_total_debits, v_total_credits;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.verify_energetics_double_entry_balance() OWNER TO u0_a315;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: edge_ledger_accounts; Type: TABLE; Schema: public; Owner: u0_a315
--

CREATE TABLE public.edge_ledger_accounts (
    account_number character varying(64) NOT NULL,
    name character varying(255) NOT NULL,
    category character varying(64) NOT NULL
);


ALTER TABLE public.edge_ledger_accounts OWNER TO u0_a315;

--
-- Name: edge_ledger_entries; Type: TABLE; Schema: public; Owner: u0_a315
--

CREATE TABLE public.edge_ledger_entries (
    entry_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    domain_id character varying(64) NOT NULL,
    description text NOT NULL,
    posted_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.edge_ledger_entries OWNER TO u0_a315;

--
-- Name: edge_ledger_lines; Type: TABLE; Schema: public; Owner: u0_a315
--

CREATE TABLE public.edge_ledger_lines (
    line_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    entry_id uuid NOT NULL,
    account_number character varying(64) NOT NULL,
    debit_amount_micros bigint DEFAULT 0 NOT NULL,
    credit_amount_micros bigint DEFAULT 0 NOT NULL,
    CONSTRAINT chk_edge_debit_credit_mutex CHECK ((((debit_amount_micros > 0) AND (credit_amount_micros = 0)) OR ((credit_amount_micros > 0) AND (debit_amount_micros = 0)))),
    CONSTRAINT edge_ledger_lines_credit_amount_micros_check CHECK ((credit_amount_micros >= 0)),
    CONSTRAINT edge_ledger_lines_debit_amount_micros_check CHECK ((debit_amount_micros >= 0))
);


ALTER TABLE public.edge_ledger_lines OWNER TO u0_a315;

--
-- Name: energetics_settlement_entries; Type: TABLE; Schema: public; Owner: u0_a315
--

CREATE TABLE public.energetics_settlement_entries (
    entry_id uuid DEFAULT gen_random_uuid() NOT NULL,
    idempotency_key character varying(128) NOT NULL,
    domain_id character varying(32) NOT NULL,
    iso_rto_node_id character varying(64) NOT NULL,
    dispatched_energy_uwh bigint NOT NULL,
    lmp_price_per_mwh_micro_usd bigint CONSTRAINT energetics_settlement_entri_lmp_price_per_mwh_micro_us_not_null NOT NULL,
    irc_45y_ptc_micro_usd bigint DEFAULT 0 NOT NULL,
    aaufsa_sec_5000f_tax_micro_usd bigint DEFAULT 0 CONSTRAINT energetics_settlement_entri_aaufsa_sec_5000f_tax_micro_not_null NOT NULL,
    aaufsa_oasdi_75_pct_micro_usd bigint DEFAULT 0 CONSTRAINT energetics_settlement_entri_aaufsa_oasdi_75_pct_micro__not_null NOT NULL,
    aaufsa_reskilling_25_pct_micro_usd bigint DEFAULT 0 CONSTRAINT energetics_settlement_entri_aaufsa_reskilling_25_pct_m_not_null NOT NULL,
    aaufsa_statutory_basis character varying(256) NOT NULL,
    posted_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT chk_aaufsa_trust_fund_split CHECK ((aaufsa_sec_5000f_tax_micro_usd = (aaufsa_oasdi_75_pct_micro_usd + aaufsa_reskilling_25_pct_micro_usd))),
    CONSTRAINT energetics_settlement_entrie_aaufsa_oasdi_75_pct_micro_us_check CHECK ((aaufsa_oasdi_75_pct_micro_usd >= 0)),
    CONSTRAINT energetics_settlement_entrie_aaufsa_reskilling_25_pct_mic_check CHECK ((aaufsa_reskilling_25_pct_micro_usd >= 0)),
    CONSTRAINT energetics_settlement_entrie_aaufsa_sec_5000f_tax_micro_u_check CHECK ((aaufsa_sec_5000f_tax_micro_usd >= 0)),
    CONSTRAINT energetics_settlement_entries_dispatched_energy_uwh_check CHECK ((dispatched_energy_uwh >= 0)),
    CONSTRAINT energetics_settlement_entries_domain_id_check CHECK (((domain_id)::text = ANY ((ARRAY['877771073297'::character varying, '964521086569'::character varying, '188680247367'::character varying, '1087754464927'::character varying, '282230018778'::character varying, '358233233'::character varying])::text[]))),
    CONSTRAINT energetics_settlement_entries_irc_45y_ptc_micro_usd_check CHECK ((irc_45y_ptc_micro_usd >= 0)),
    CONSTRAINT energetics_settlement_entries_lmp_price_per_mwh_micro_usd_check CHECK ((lmp_price_per_mwh_micro_usd >= 0))
);

ALTER TABLE ONLY public.energetics_settlement_entries FORCE ROW LEVEL SECURITY;


ALTER TABLE public.energetics_settlement_entries OWNER TO u0_a315;

--
-- Name: energetics_settlement_lines; Type: TABLE; Schema: public; Owner: u0_a315
--

CREATE TABLE public.energetics_settlement_lines (
    line_id uuid DEFAULT gen_random_uuid() NOT NULL,
    entry_id uuid NOT NULL,
    domain_id character varying(32) NOT NULL,
    account_code character varying(64) NOT NULL,
    debit_micro_usd bigint DEFAULT 0 NOT NULL,
    credit_micro_usd bigint DEFAULT 0 NOT NULL,
    CONSTRAINT chk_non_zero_exclusive_leg CHECK ((((debit_micro_usd > 0) AND (credit_micro_usd = 0)) OR ((credit_micro_usd > 0) AND (debit_micro_usd = 0)))),
    CONSTRAINT energetics_settlement_lines_credit_micro_usd_check CHECK ((credit_micro_usd >= 0)),
    CONSTRAINT energetics_settlement_lines_debit_micro_usd_check CHECK ((debit_micro_usd >= 0)),
    CONSTRAINT energetics_settlement_lines_domain_id_check CHECK (((domain_id)::text = ANY ((ARRAY['877771073297'::character varying, '964521086569'::character varying, '188680247367'::character varying, '1087754464927'::character varying, '282230018778'::character varying, '358233233'::character varying])::text[])))
);

ALTER TABLE ONLY public.energetics_settlement_lines FORCE ROW LEVEL SECURITY;


ALTER TABLE public.energetics_settlement_lines OWNER TO u0_a315;

--
-- Name: ledger_accounts; Type: TABLE; Schema: public; Owner: u0_a315
--

CREATE TABLE public.ledger_accounts (
    account_id uuid DEFAULT gen_random_uuid() NOT NULL,
    account_number character varying(32) NOT NULL,
    name character varying(128) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ledger_accounts OWNER TO u0_a315;

--
-- Name: ledger_entries; Type: TABLE; Schema: public; Owner: u0_a315
--

CREATE TABLE public.ledger_entries (
    entry_id uuid DEFAULT gen_random_uuid() NOT NULL,
    stripe_event_id character varying(128) NOT NULL,
    description text NOT NULL,
    posted_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ledger_entries OWNER TO u0_a315;

--
-- Name: ledger_lines; Type: TABLE; Schema: public; Owner: u0_a315
--

CREATE TABLE public.ledger_lines (
    line_id uuid DEFAULT gen_random_uuid() NOT NULL,
    entry_id uuid NOT NULL,
    account_id uuid NOT NULL,
    debit_amount_cents bigint DEFAULT 0 NOT NULL,
    credit_amount_cents bigint DEFAULT 0 NOT NULL,
    CONSTRAINT chk_debit_or_credit CHECK ((((debit_amount_cents > 0) AND (credit_amount_cents = 0)) OR ((credit_amount_cents > 0) AND (debit_amount_cents = 0)))),
    CONSTRAINT ledger_lines_credit_amount_cents_check CHECK ((credit_amount_cents >= 0)),
    CONSTRAINT ledger_lines_debit_amount_cents_check CHECK ((debit_amount_cents >= 0))
);


ALTER TABLE public.ledger_lines OWNER TO u0_a315;

--
-- Name: view_income_statement; Type: VIEW; Schema: public; Owner: u0_a315
--

CREATE VIEW public.view_income_statement AS
 SELECT COALESCE(sum(
        CASE
            WHEN ((a.account_number)::text = ANY ((ARRAY['4000-SUBSCRIPTION-REV'::character varying, '4010-RECURRING-SUBSCRIPTION-REV'::character varying])::text[])) THEN l.credit_amount_cents
            ELSE (0)::bigint
        END), (0)::numeric) AS gross_revenue_cents,
    COALESCE(sum(
        CASE
            WHEN ((a.account_number)::text = '4100-REFUNDS-CONTRA'::text) THEN l.debit_amount_cents
            ELSE (0)::bigint
        END), (0)::numeric) AS refunds_cents,
    COALESCE(sum(
        CASE
            WHEN ((a.account_number)::text = '5000-STRIPE-PROCESSING-FEE'::text) THEN l.debit_amount_cents
            ELSE (0)::bigint
        END), (0)::numeric) AS processing_fees_cents,
    ((COALESCE(sum(
        CASE
            WHEN ((a.account_number)::text = ANY ((ARRAY['4000-SUBSCRIPTION-REV'::character varying, '4010-RECURRING-SUBSCRIPTION-REV'::character varying])::text[])) THEN l.credit_amount_cents
            ELSE (0)::bigint
        END), (0)::numeric) - COALESCE(sum(
        CASE
            WHEN ((a.account_number)::text = '4100-REFUNDS-CONTRA'::text) THEN l.debit_amount_cents
            ELSE (0)::bigint
        END), (0)::numeric)) - COALESCE(sum(
        CASE
            WHEN ((a.account_number)::text = '5000-STRIPE-PROCESSING-FEE'::text) THEN l.debit_amount_cents
            ELSE (0)::bigint
        END), (0)::numeric)) AS net_operating_income_cents
   FROM (public.ledger_accounts a
     JOIN public.ledger_lines l ON ((a.account_id = l.account_id)));


ALTER VIEW public.view_income_statement OWNER TO u0_a315;

--
-- Name: view_trial_balance; Type: VIEW; Schema: public; Owner: u0_a315
--

CREATE VIEW public.view_trial_balance AS
 SELECT a.account_number,
    a.name,
    a.currency,
    COALESCE(sum(l.debit_amount_cents), (0)::numeric) AS total_debits_cents,
    COALESCE(sum(l.credit_amount_cents), (0)::numeric) AS total_credits_cents,
        CASE
            WHEN (((a.account_number)::text ~~ '1%'::text) OR ((a.account_number)::text ~~ '5%'::text)) THEN (COALESCE(sum(l.debit_amount_cents), (0)::numeric) - COALESCE(sum(l.credit_amount_cents), (0)::numeric))
            ELSE (COALESCE(sum(l.credit_amount_cents), (0)::numeric) - COALESCE(sum(l.debit_amount_cents), (0)::numeric))
        END AS net_balance_cents
   FROM (public.ledger_accounts a
     LEFT JOIN public.ledger_lines l ON ((a.account_id = l.account_id)))
  GROUP BY a.account_number, a.name, a.currency
  ORDER BY a.account_number;


ALTER VIEW public.view_trial_balance OWNER TO u0_a315;

--
-- Name: vpp_synchrophasor_dispatch_events; Type: TABLE; Schema: public; Owner: u0_a315
--

CREATE TABLE public.vpp_synchrophasor_dispatch_events (
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    holding_org_id character varying(32) DEFAULT '320717657398'::character varying NOT NULL,
    domain_id character varying(32) NOT NULL,
    lifecycle_folder_id character varying(32) NOT NULL,
    vpp_resource_id character varying(128) NOT NULL,
    grid_freq_uhz bigint NOT NULL,
    grid_voltage_micro_pu bigint CONSTRAINT vpp_synchrophasor_dispatch_event_grid_voltage_micro_pu_not_null NOT NULL,
    phase_angle_diff_udeg bigint CONSTRAINT vpp_synchrophasor_dispatch_event_phase_angle_diff_udeg_not_null NOT NULL,
    rocof_uhz_per_sec bigint NOT NULL,
    ptp_time_skew_ns bigint NOT NULL,
    dispatched_active_power_uw bigint CONSTRAINT vpp_synchrophasor_dispatch__dispatched_active_power_uw_not_null NOT NULL,
    dispatched_reactive_power_uvar bigint CONSTRAINT vpp_synchrophasor_dispatch__dispatched_reactive_power__not_null NOT NULL,
    dispatched_energy_uwh bigint CONSTRAINT vpp_synchrophasor_dispatch_event_dispatched_energy_uwh_not_null NOT NULL,
    primary_operator_id character varying(128) NOT NULL,
    secondary_engineer_id character varying(128) CONSTRAINT vpp_synchrophasor_dispatch_event_secondary_engineer_id_not_null NOT NULL,
    recorded_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    event_sha256 character(64) NOT NULL,
    CONSTRAINT vpp_synchrophasor_dispatch_events_check CHECK (((primary_operator_id)::text <> (secondary_engineer_id)::text)),
    CONSTRAINT vpp_synchrophasor_dispatch_events_dispatched_energy_uwh_check CHECK ((dispatched_energy_uwh >= 0)),
    CONSTRAINT vpp_synchrophasor_dispatch_events_domain_id_check CHECK (((domain_id)::text = ANY ((ARRAY['877771073297'::character varying, '964521086569'::character varying, '188680247367'::character varying, '1087754464927'::character varying, '282230018778'::character varying, '358233233'::character varying])::text[]))),
    CONSTRAINT vpp_synchrophasor_dispatch_events_grid_freq_uhz_check CHECK (((grid_freq_uhz >= 59950000) AND (grid_freq_uhz <= 60050000))),
    CONSTRAINT vpp_synchrophasor_dispatch_events_grid_voltage_micro_pu_check CHECK (((grid_voltage_micro_pu >= 950000) AND (grid_voltage_micro_pu <= 1050000))),
    CONSTRAINT vpp_synchrophasor_dispatch_events_holding_org_id_check CHECK (((holding_org_id)::text = '320717657398'::text)),
    CONSTRAINT vpp_synchrophasor_dispatch_events_lifecycle_folder_id_check CHECK (((lifecycle_folder_id)::text = ANY ((ARRAY['938478392755'::character varying, '978426653396'::character varying, '467686749558'::character varying, '10470744625'::character varying])::text[]))),
    CONSTRAINT vpp_synchrophasor_dispatch_events_phase_angle_diff_udeg_check CHECK ((abs(phase_angle_diff_udeg) <= 10000000)),
    CONSTRAINT vpp_synchrophasor_dispatch_events_ptp_time_skew_ns_check CHECK ((ptp_time_skew_ns <= 1000)),
    CONSTRAINT vpp_synchrophasor_dispatch_events_rocof_uhz_per_sec_check CHECK ((abs(rocof_uhz_per_sec) <= 500000))
);

ALTER TABLE ONLY public.vpp_synchrophasor_dispatch_events FORCE ROW LEVEL SECURITY;


ALTER TABLE public.vpp_synchrophasor_dispatch_events OWNER TO u0_a315;

--
-- Data for Name: edge_ledger_accounts; Type: TABLE DATA; Schema: public; Owner: u0_a315
--

COPY public.edge_ledger_accounts (account_number, name, category) FROM stdin;
1000-VPP-EDGE-CLEARING	Virtual Power Plant Edge Compute Clearing	ASSET
2200-OASI-DI-FIDUCIARY-PAYABLE	Social Security Fiduciary Payable (75%)	LIABILITY
2210-RESKILLING-FUND-PAYABLE	National Workforce Reskilling Trust (25%)	LIABILITY
4000-EDGE-COMPUTE-REV	Edge Computational Unit Revenue	REVENUE
5200-AAUFSA-TAX-EXPENSE	IRC Chapter 56 Edge Automation Tax	EXPENSE
\.


--
-- Data for Name: edge_ledger_entries; Type: TABLE DATA; Schema: public; Owner: u0_a315
--

COPY public.edge_ledger_entries (entry_id, domain_id, description, posted_at) FROM stdin;
72de105c-d04c-4bd8-ad5b-de529aec5fc9	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 16:10:07.965379-04
f62bd50e-95fe-4dba-89d9-95dc25f4e17a	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 16:15:00.717842-04
be02ef74-2bd4-4505-84f3-76180f603e1a	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 16:30:00.98906-04
7904cc26-3cf9-4fa6-92a1-c7a879e78291	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 16:45:00.946543-04
b973cab8-2a47-4a17-83be-2434f5633944	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 17:00:00.548127-04
877be8e3-d806-453f-a9a4-a72f5da3b7c6	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 17:15:00.26661-04
5d2fed36-aec2-4be9-a7d6-dcc8121a4789	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 17:30:00.943571-04
e26c2eff-aed9-4f73-9474-b58b3bae87ab	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 17:45:00.814628-04
32f1b895-db58-449f-b733-7f52dbbda285	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 18:00:00.699561-04
0652552d-4b31-47ce-9338-6dd9f13571fe	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 18:15:01.274555-04
6b005591-3096-4c05-ac37-0ae1e917e1e4	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 18:30:00.96087-04
d850a09d-2ceb-4c7a-841c-e5f121bbd9df	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 18:45:00.873667-04
843b1648-a207-4ada-8f19-b2053170f5f4	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 19:00:00.349783-04
ea293697-a24a-4dae-8774-4ae4484ea7a8	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 19:15:00.441524-04
68e2b488-caee-4588-b921-c5fc91774fd2	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 19:30:01.389992-04
01229324-069e-4701-a467-bc51f71baf64	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 19:45:00.891319-04
1702791a-06f5-4681-9f9f-6d41e7856b2f	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 20:00:00.722108-04
07b9e0ac-7da9-41e3-be15-d2159f2934e7	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 20:15:01.201879-04
3c9d4b56-c127-4218-b03a-a49e8708e984	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 20:30:00.444731-04
34a7b13c-1528-48c4-b899-da3ddbaa4e06	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 20:45:00.528213-04
a1fb1361-70ad-4066-80af-7d521d2db692	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 21:00:00.851212-04
1ca9507b-4e57-44d2-9899-2b36ab46236d	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 21:15:00.498638-04
d173e7ac-246b-492c-9afb-ef9376bbc2e0	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 21:30:01.263731-04
56ae635a-2a3d-4cd7-9537-6b73d4cde61a	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 21:45:00.844551-04
c90858d2-0406-43c0-a37c-c0a1264942a1	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 22:00:01.119748-04
13fe649f-f3f8-4057-8949-d6e477f5e3e3	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 22:15:00.736254-04
e373984f-e9b3-42b9-a460-240026d4b6b7	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 22:30:01.02241-04
7be707c9-6bd3-4f4b-a307-fd61784801c9	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 22:45:00.967933-04
4e36d970-9103-4710-ac01-7d03b7e035ed	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 23:00:00.667554-04
5cd59a86-cb13-44be-bab9-ea417bd9c374	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 23:15:00.343987-04
95e55d63-d805-4bd1-a3ac-959d719e667c	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 23:30:00.614932-04
2a4093fc-c44e-4f54-996c-57e633d98571	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-30 23:45:00.916105-04
509f4c34-34f4-4e17-b352-6007c638b00b	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 00:00:00.487447-04
633aef8b-3cf4-4e7c-8b0e-9a3b0fa41abd	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 00:15:00.554862-04
5efbd23a-f50b-4945-bd55-92a59d6edb44	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 00:30:00.267562-04
8d0553c5-ea44-41f1-b897-cbea00a03752	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 00:45:00.466663-04
da9b7940-6629-4a9b-9a98-9310228b9b06	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 01:00:00.711769-04
2be156c7-ce68-4039-896e-5af3e83976b8	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 01:15:01.416424-04
e72d7eae-cbfb-4dd6-85de-c22e4a69c855	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 01:30:00.358551-04
b55396a8-9385-42e8-b64d-f960443d4e45	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 01:45:00.527609-04
e95cfea2-37f3-4187-9417-a30fa2d7c817	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 02:00:00.564218-04
8d36e2e9-3d9f-4581-b7b1-361ac950a39d	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 02:15:00.978933-04
dc10482a-54f3-41dd-811d-737ea696cd06	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 02:30:01.006951-04
6b8b01cd-41f7-4312-86b7-a9c60c495412	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 02:45:00.387539-04
08f8d00c-bac0-4c28-a096-00af3e56c557	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 03:00:00.207831-04
840f220e-7234-4a82-b220-d6b1d026a25e	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 03:15:00.331562-04
ca949cb3-2f9a-4af8-b47d-8f9214eadae5	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 03:30:00.330881-04
dbbbd490-bb6d-4381-9a50-e070ba03d7a1	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 03:45:00.271534-04
82dcc7db-ee81-4423-91e5-1af2259d1e5d	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 04:00:00.359663-04
31eeb524-c892-4181-a14e-ca3b2f17a7c5	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 04:15:00.715448-04
b2ab42b9-59f9-48ec-a722-d94fdb8c05d9	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 04:30:00.815983-04
e4f1d90e-f97e-4f48-a2af-c632dbad6ab3	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 04:45:00.82151-04
79771330-4c4c-4a04-8218-b12a55809221	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 05:00:00.400323-04
e7d38853-f8aa-4800-ae66-06ad75a0b779	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 05:15:00.82267-04
88b96c52-f892-41f0-a7e3-4c7961bec217	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 05:30:00.946059-04
35dac487-1668-423d-8a20-a3d14eaf4bf4	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 05:45:00.44664-04
7ad59f05-0902-4351-a3b8-10ac3bef28dc	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 06:00:00.286138-04
0cbb4a98-b23b-4399-9cd4-6c6267a0e6a4	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 06:15:00.349418-04
0a7fe9f5-1f26-49d4-88b8-9d0a473fddda	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 06:30:00.560881-04
1d29a24e-8f4c-402c-b443-c61a8c20bfe2	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 06:45:00.641911-04
9485bdee-9f55-4af7-b2eb-a7b606465c6a	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 07:00:00.160191-04
d4cab496-6003-46ec-8adb-fffff85e0bf6	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 07:15:01.027782-04
697a510a-1f48-4fb4-a6a9-d88f4b7aec00	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 07:30:00.239732-04
fbcd5032-0d44-4224-a21f-d58d26970368	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 07:45:00.801654-04
5c35028e-7747-408e-9505-c19edbd0b585	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 08:00:00.927234-04
4249eb47-46f3-4f79-b181-8991e457a8fd	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 08:15:01.038667-04
9ba7cfc2-c65b-4e60-9738-93bb9d2428ce	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 08:30:00.711301-04
c912d065-0cc7-4c7b-90a8-e225698622bd	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 08:45:00.67911-04
7c5ccc06-a312-4ecc-90eb-5828720a7dd7	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 09:00:00.447206-04
56e18bcb-f9c2-47ff-8e46-03eee91ab3fa	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 09:15:00.756341-04
d2e27296-79ee-4772-b2ed-aa981d3e96ac	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 09:30:00.985618-04
63ca6dea-7eaa-4edc-8f2f-4885c9a54f71	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 09:45:00.886202-04
8d7e2d99-be65-4d1f-b53a-ad75712e0453	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 10:00:01.279415-04
f2086d4d-1fe8-48d8-8b5e-e0e47d9517b8	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 10:15:00.838887-04
048b4bdd-d5cc-483d-9073-bf79cb01aff3	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 10:30:00.306594-04
23dc980d-8b60-4d56-bd97-c05ad8906c71	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 10:45:00.459779-04
e653b691-d8ef-4794-97ae-261b780f9a2c	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 11:00:00.40717-04
67dd6151-fe59-4e26-af39-edd94381f030	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 11:15:00.852048-04
8f967e3c-6596-4732-855e-1c23f64019cc	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 11:30:00.449896-04
f8b1c0bd-9f7a-46e0-a4ae-b9f0cbaa455a	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 11:45:00.140034-04
13cb7be3-3928-4dcd-907f-b463a4d776d0	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 12:00:00.88725-04
60af2f00-588b-4720-909a-8da33f732b43	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 12:15:00.130733-04
0a9f7ab5-4cf2-4590-a3cf-4539e4928265	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 12:30:01.023205-04
02b9ea79-f8ba-4f52-81b8-662bce9c1d59	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 12:45:00.268184-04
be5bad9f-7b5b-484d-8976-d9d4dbd8b54b	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 13:00:01.102684-04
91dd9985-c38e-4b4d-a7ce-fd3682d593a8	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 13:15:00.604934-04
89a00b9f-ba72-4872-9652-8bcd48ecfc68	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 13:30:00.502473-04
3c2cd0db-1262-496b-ad9e-8f144ed2d57b	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 13:45:00.224274-04
524de706-2679-4739-bac8-f47fa3371ec6	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 14:00:00.777678-04
6b7dbd39-ed85-4213-ace4-c51deb88bc99	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 14:15:00.807808-04
6e38c6c2-09de-49fe-80e5-6a743b4acad2	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 14:30:00.377916-04
72e7b489-e8f3-4848-b042-ff8d1c6397ed	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 14:45:01.058555-04
d472117a-9de1-4341-8d5b-0d452fd2e658	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 15:00:01.050692-04
ca0e86fd-1a27-4a11-ab32-f7ced6b819a2	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 15:15:00.636643-04
dc5c1574-851f-4310-a098-20a4b458275d	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 15:30:00.626865-04
29adfa16-d795-4f61-8648-523e2e43912b	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 15:45:00.224958-04
df8faf1d-30dd-4e05-840e-b40faf91b494	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 16:00:00.812726-04
2d96b74b-1f80-469b-9624-b0264cb1ed0b	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 16:15:00.636085-04
5e1c553f-f4ef-45ae-8726-512560875141	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 16:30:01.017792-04
bf7e327e-8038-462b-93c6-1ec6306e6574	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 16:45:01.147417-04
80c3572d-0314-4eb6-b5f1-c5475b0f9c14	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 17:00:01.1707-04
3aa8d99b-f4de-4de8-a47b-5ffa765eeea0	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 17:15:00.873194-04
01ba641b-82d6-4835-9933-0765b283e132	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 17:30:00.298134-04
d0d28c78-975e-48c9-a079-99ce4bfdd8f5	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 17:45:00.189868-04
b8f0b3c1-55cb-43cc-a3e6-47b9bd004b1f	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 18:00:00.739951-04
ba256560-e96c-4083-9c49-8854fe0a77e6	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 18:15:00.913173-04
de965f80-c166-49a6-aa72-624d2514168b	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 18:30:00.171612-04
3910bdea-87ce-459f-b371-d565a2a280d1	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 18:45:01.14304-04
0091ac7d-b026-495c-af07-4838861c567d	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 19:00:00.394286-04
4688a0ac-5555-4329-a913-5443fcdcd2c2	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 21:30:01.14564-04
a0662732-c373-460b-a7cf-70a063f228a6	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 21:45:00.747713-04
4893246b-9b3a-4acf-a3db-536c9a9d5062	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 22:00:01.135247-04
6ee9edeb-128d-40a4-bd61-834a7bc3487d	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 22:15:00.817704-04
cbb13499-c1a1-4206-b08d-d8b545fd2465	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 22:30:00.550259-04
1ea6dd68-f018-48e6-9dd3-01e67b821388	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 22:45:00.247269-04
883c2682-fafa-4a64-90a8-59da566baa7a	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 23:00:00.333161-04
62fd4a71-7ebd-4726-8a6a-ca2fa884349f	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 23:15:01.007172-04
72d9eb7c-3ba7-4bff-878f-8efcf84bce53	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 23:30:00.567028-04
e07f7f0a-7556-4b84-9276-8c3876b506c2	188680247367	IRC Sec. 5000H(d) Cloud/SaaS Provider Immunity	2026-10-31 23:45:01.199058-04
\.


--
-- Data for Name: edge_ledger_lines; Type: TABLE DATA; Schema: public; Owner: u0_a315
--

COPY public.edge_ledger_lines (line_id, entry_id, account_number, debit_amount_micros, credit_amount_micros) FROM stdin;
ae3ec1f5-78d6-4fef-abbb-054ce2ffe986	72de105c-d04c-4bd8-ad5b-de529aec5fc9	1000-VPP-EDGE-CLEARING	250000000	0
4f8dd430-7f5e-4621-8278-bab80e04f45f	72de105c-d04c-4bd8-ad5b-de529aec5fc9	4000-EDGE-COMPUTE-REV	0	250000000
6481cb85-39bd-4ebb-b734-a7b8842190cc	f62bd50e-95fe-4dba-89d9-95dc25f4e17a	1000-VPP-EDGE-CLEARING	250000000	0
4d5f9d84-d610-460b-92b8-b6bf5b7c9a91	f62bd50e-95fe-4dba-89d9-95dc25f4e17a	4000-EDGE-COMPUTE-REV	0	250000000
b8a2ec6b-4f7b-4ecd-89a9-9f07bd291c8a	be02ef74-2bd4-4505-84f3-76180f603e1a	1000-VPP-EDGE-CLEARING	250000000	0
c544c855-4569-4456-b0ec-4a742c8c42e2	be02ef74-2bd4-4505-84f3-76180f603e1a	4000-EDGE-COMPUTE-REV	0	250000000
80595d01-8bee-4472-8e25-c86b4b83f872	7904cc26-3cf9-4fa6-92a1-c7a879e78291	1000-VPP-EDGE-CLEARING	250000000	0
de45dffc-5a12-407d-8a16-ae4ef24446ff	7904cc26-3cf9-4fa6-92a1-c7a879e78291	4000-EDGE-COMPUTE-REV	0	250000000
f75ea183-937f-4d03-8831-9a08748f6340	b973cab8-2a47-4a17-83be-2434f5633944	1000-VPP-EDGE-CLEARING	250000000	0
2d7b644d-7b4b-4c7f-a477-86691b265723	b973cab8-2a47-4a17-83be-2434f5633944	4000-EDGE-COMPUTE-REV	0	250000000
b87b006f-3766-4199-8a7b-10f32ad2a5a3	877be8e3-d806-453f-a9a4-a72f5da3b7c6	1000-VPP-EDGE-CLEARING	250000000	0
ce61e550-4bb9-483a-9d2e-a36e76751bb5	877be8e3-d806-453f-a9a4-a72f5da3b7c6	4000-EDGE-COMPUTE-REV	0	250000000
edc33039-f50c-48c8-ab1e-ae5d8c6d6d44	5d2fed36-aec2-4be9-a7d6-dcc8121a4789	1000-VPP-EDGE-CLEARING	250000000	0
9147e608-1976-4789-b8b0-2f6907350bf2	5d2fed36-aec2-4be9-a7d6-dcc8121a4789	4000-EDGE-COMPUTE-REV	0	250000000
1cb666f3-570f-4a9f-846d-95c511f3e24a	e26c2eff-aed9-4f73-9474-b58b3bae87ab	1000-VPP-EDGE-CLEARING	250000000	0
bbf9733a-2385-4695-9c5e-de46b33c1a15	e26c2eff-aed9-4f73-9474-b58b3bae87ab	4000-EDGE-COMPUTE-REV	0	250000000
9d6bfaf1-e5e3-4345-a843-8f614f0c92ea	32f1b895-db58-449f-b733-7f52dbbda285	1000-VPP-EDGE-CLEARING	250000000	0
cd76ef5e-4b1a-431e-b1b0-0cf7a2946d5d	32f1b895-db58-449f-b733-7f52dbbda285	4000-EDGE-COMPUTE-REV	0	250000000
d1f17562-b908-43f9-a621-52a95e11f399	0652552d-4b31-47ce-9338-6dd9f13571fe	1000-VPP-EDGE-CLEARING	250000000	0
dda15720-7ae4-4472-a27a-6ee680ba6b11	0652552d-4b31-47ce-9338-6dd9f13571fe	4000-EDGE-COMPUTE-REV	0	250000000
dbf8522b-43ae-47d8-9a42-431b2e87f043	6b005591-3096-4c05-ac37-0ae1e917e1e4	1000-VPP-EDGE-CLEARING	250000000	0
3f88a7b3-7fc2-45e9-940c-4540c40ef823	6b005591-3096-4c05-ac37-0ae1e917e1e4	4000-EDGE-COMPUTE-REV	0	250000000
d8b57aee-fcbf-4bf2-81ae-0e66067c9424	d850a09d-2ceb-4c7a-841c-e5f121bbd9df	1000-VPP-EDGE-CLEARING	250000000	0
f010a451-52aa-4ca5-bdf2-98a1c7d287e0	d850a09d-2ceb-4c7a-841c-e5f121bbd9df	4000-EDGE-COMPUTE-REV	0	250000000
c01838da-4d6f-46cc-ae42-7fb60be093b6	843b1648-a207-4ada-8f19-b2053170f5f4	1000-VPP-EDGE-CLEARING	250000000	0
2c525384-d059-490c-ada9-53f99fc0a457	843b1648-a207-4ada-8f19-b2053170f5f4	4000-EDGE-COMPUTE-REV	0	250000000
f2e27862-b243-4383-879c-dd193c393007	ea293697-a24a-4dae-8774-4ae4484ea7a8	1000-VPP-EDGE-CLEARING	250000000	0
9abfc32f-a50c-41a7-9b55-fb4c651b8ef2	ea293697-a24a-4dae-8774-4ae4484ea7a8	4000-EDGE-COMPUTE-REV	0	250000000
a8580367-9589-4247-a666-405d5758c2f4	68e2b488-caee-4588-b921-c5fc91774fd2	1000-VPP-EDGE-CLEARING	250000000	0
7a4a2c3e-69aa-4863-92d6-0c671e93e6d6	68e2b488-caee-4588-b921-c5fc91774fd2	4000-EDGE-COMPUTE-REV	0	250000000
664ced42-d9b1-49f7-bc91-e4a0a6b64ca3	01229324-069e-4701-a467-bc51f71baf64	1000-VPP-EDGE-CLEARING	250000000	0
763c868f-f3f2-4818-aa41-8f2d783b6936	01229324-069e-4701-a467-bc51f71baf64	4000-EDGE-COMPUTE-REV	0	250000000
1a610ae3-32a8-4054-86f6-ad4943f660a8	1702791a-06f5-4681-9f9f-6d41e7856b2f	1000-VPP-EDGE-CLEARING	250000000	0
08757909-6843-4ef7-bf12-29b57cfccb6b	1702791a-06f5-4681-9f9f-6d41e7856b2f	4000-EDGE-COMPUTE-REV	0	250000000
7e9cda97-2813-4bdc-ad86-1fb4d92c0ff9	07b9e0ac-7da9-41e3-be15-d2159f2934e7	1000-VPP-EDGE-CLEARING	250000000	0
69e4cf2a-1c9d-4cc0-9aae-84ec3706bb33	07b9e0ac-7da9-41e3-be15-d2159f2934e7	4000-EDGE-COMPUTE-REV	0	250000000
d83b180f-473b-423d-9664-07e2d080c172	3c9d4b56-c127-4218-b03a-a49e8708e984	1000-VPP-EDGE-CLEARING	250000000	0
5a9dbc7b-d778-4a32-bf6a-b768aa4f5d89	3c9d4b56-c127-4218-b03a-a49e8708e984	4000-EDGE-COMPUTE-REV	0	250000000
c92de171-964d-481b-8963-b5ddbcfd1dc3	34a7b13c-1528-48c4-b899-da3ddbaa4e06	1000-VPP-EDGE-CLEARING	250000000	0
d3f68371-abe1-41e2-8003-5a9713e0a00e	34a7b13c-1528-48c4-b899-da3ddbaa4e06	4000-EDGE-COMPUTE-REV	0	250000000
166ea780-7e34-4b03-8a90-5bdedc8a0019	a1fb1361-70ad-4066-80af-7d521d2db692	1000-VPP-EDGE-CLEARING	250000000	0
78af8dff-056c-4305-80ee-938465412744	a1fb1361-70ad-4066-80af-7d521d2db692	4000-EDGE-COMPUTE-REV	0	250000000
b68abbc1-1e6e-4a94-9f29-5bbcd4c5fb86	1ca9507b-4e57-44d2-9899-2b36ab46236d	1000-VPP-EDGE-CLEARING	250000000	0
c4c905ca-0ec3-4eac-8232-5c2cdbd9cfab	1ca9507b-4e57-44d2-9899-2b36ab46236d	4000-EDGE-COMPUTE-REV	0	250000000
9d2cc653-b212-4c6b-a7eb-38435252cf8b	d173e7ac-246b-492c-9afb-ef9376bbc2e0	1000-VPP-EDGE-CLEARING	250000000	0
47309656-637e-44ec-8155-3d45ce352fd3	d173e7ac-246b-492c-9afb-ef9376bbc2e0	4000-EDGE-COMPUTE-REV	0	250000000
57474112-e774-416b-a7e3-ecf983d4f552	56ae635a-2a3d-4cd7-9537-6b73d4cde61a	1000-VPP-EDGE-CLEARING	250000000	0
870120e2-bca6-4af2-b92e-7acb1f781345	56ae635a-2a3d-4cd7-9537-6b73d4cde61a	4000-EDGE-COMPUTE-REV	0	250000000
c050d58e-d281-43ba-b417-d5ec5fff42d4	c90858d2-0406-43c0-a37c-c0a1264942a1	1000-VPP-EDGE-CLEARING	250000000	0
0037c5f1-844a-47f4-9b33-96a52a545dfa	c90858d2-0406-43c0-a37c-c0a1264942a1	4000-EDGE-COMPUTE-REV	0	250000000
07db205c-52ec-4457-9f7c-1908d8c2f39e	13fe649f-f3f8-4057-8949-d6e477f5e3e3	1000-VPP-EDGE-CLEARING	250000000	0
53a127c8-d272-440a-9fd7-8f78c876304e	13fe649f-f3f8-4057-8949-d6e477f5e3e3	4000-EDGE-COMPUTE-REV	0	250000000
204a2e99-e7c1-4f9e-b219-14517c012759	e373984f-e9b3-42b9-a460-240026d4b6b7	1000-VPP-EDGE-CLEARING	250000000	0
525b9db2-2fe2-4080-a26f-f3db9325c2bd	e373984f-e9b3-42b9-a460-240026d4b6b7	4000-EDGE-COMPUTE-REV	0	250000000
b87eac37-a300-44e3-91ca-c57e3ce89c37	7be707c9-6bd3-4f4b-a307-fd61784801c9	1000-VPP-EDGE-CLEARING	250000000	0
3cf37242-56ea-4814-8c14-7515d150c53f	7be707c9-6bd3-4f4b-a307-fd61784801c9	4000-EDGE-COMPUTE-REV	0	250000000
db1d550c-a7af-478f-94ce-59778bdf3758	4e36d970-9103-4710-ac01-7d03b7e035ed	1000-VPP-EDGE-CLEARING	250000000	0
953b09e9-d109-4587-911d-b56af80fd811	4e36d970-9103-4710-ac01-7d03b7e035ed	4000-EDGE-COMPUTE-REV	0	250000000
0dbd5e7b-6fa1-45fe-8eb6-21e9aa0deecc	5cd59a86-cb13-44be-bab9-ea417bd9c374	1000-VPP-EDGE-CLEARING	250000000	0
c57098c5-e5c8-4bf2-b15d-42e4f0b3ddf8	5cd59a86-cb13-44be-bab9-ea417bd9c374	4000-EDGE-COMPUTE-REV	0	250000000
a439c571-3b19-422a-b583-1c54d9b58699	95e55d63-d805-4bd1-a3ac-959d719e667c	1000-VPP-EDGE-CLEARING	250000000	0
ac6aac9c-558b-4934-95a3-a9b955ab568a	95e55d63-d805-4bd1-a3ac-959d719e667c	4000-EDGE-COMPUTE-REV	0	250000000
36c424c6-c4a6-46b7-9d72-f2095f4b3b9b	2a4093fc-c44e-4f54-996c-57e633d98571	1000-VPP-EDGE-CLEARING	250000000	0
bdea162e-a6d9-4aa1-9d08-dfe8aa726255	2a4093fc-c44e-4f54-996c-57e633d98571	4000-EDGE-COMPUTE-REV	0	250000000
45a42634-f8cb-4901-81e2-345607dac7f2	509f4c34-34f4-4e17-b352-6007c638b00b	1000-VPP-EDGE-CLEARING	250000000	0
c65bf112-14da-468a-a904-ef1c57161c7c	509f4c34-34f4-4e17-b352-6007c638b00b	4000-EDGE-COMPUTE-REV	0	250000000
4cb0188f-6528-4a88-a9de-e355ae054d65	633aef8b-3cf4-4e7c-8b0e-9a3b0fa41abd	1000-VPP-EDGE-CLEARING	250000000	0
0451b68a-9a87-4d80-8a1c-f510b814516d	633aef8b-3cf4-4e7c-8b0e-9a3b0fa41abd	4000-EDGE-COMPUTE-REV	0	250000000
7fc8438b-f353-4456-bdc3-adc7ba296f15	5efbd23a-f50b-4945-bd55-92a59d6edb44	1000-VPP-EDGE-CLEARING	250000000	0
e81c96d1-7b0d-4a74-917c-1df2a9aba8ce	5efbd23a-f50b-4945-bd55-92a59d6edb44	4000-EDGE-COMPUTE-REV	0	250000000
23e93291-6616-47a2-b404-ecea1734122a	8d0553c5-ea44-41f1-b897-cbea00a03752	1000-VPP-EDGE-CLEARING	250000000	0
022f561c-fd8e-4194-869b-13c2739d4e3b	8d0553c5-ea44-41f1-b897-cbea00a03752	4000-EDGE-COMPUTE-REV	0	250000000
f334dc5e-b3a1-48eb-9474-ca27646b161b	da9b7940-6629-4a9b-9a98-9310228b9b06	1000-VPP-EDGE-CLEARING	250000000	0
20a86dfa-868e-47f9-852a-6a6bfff9de7a	da9b7940-6629-4a9b-9a98-9310228b9b06	4000-EDGE-COMPUTE-REV	0	250000000
897f7292-6abb-4181-a64e-f0f1af2327ce	2be156c7-ce68-4039-896e-5af3e83976b8	1000-VPP-EDGE-CLEARING	250000000	0
30622b6f-e501-4d84-8dc3-c43f7eae2c4a	2be156c7-ce68-4039-896e-5af3e83976b8	4000-EDGE-COMPUTE-REV	0	250000000
65843a5a-4ca0-431b-b946-dc9f20a41e66	e72d7eae-cbfb-4dd6-85de-c22e4a69c855	1000-VPP-EDGE-CLEARING	250000000	0
5d81d831-32e7-4f16-a75a-6091531f597e	e72d7eae-cbfb-4dd6-85de-c22e4a69c855	4000-EDGE-COMPUTE-REV	0	250000000
68d45806-33d8-49be-acbd-6c17a9e107d6	b55396a8-9385-42e8-b64d-f960443d4e45	1000-VPP-EDGE-CLEARING	250000000	0
20091d25-7191-41dc-9790-9e2ee3e8b1b7	b55396a8-9385-42e8-b64d-f960443d4e45	4000-EDGE-COMPUTE-REV	0	250000000
8a772f23-2210-4d41-bb38-a7e120229500	e95cfea2-37f3-4187-9417-a30fa2d7c817	1000-VPP-EDGE-CLEARING	250000000	0
7511fae2-d2a2-4ff1-a847-06c06d5cf6a8	e95cfea2-37f3-4187-9417-a30fa2d7c817	4000-EDGE-COMPUTE-REV	0	250000000
cf5aa68b-822d-40d3-889b-ef067a51acc5	8d36e2e9-3d9f-4581-b7b1-361ac950a39d	1000-VPP-EDGE-CLEARING	250000000	0
9a06bae8-19a5-4787-bb00-787e4e310c1d	8d36e2e9-3d9f-4581-b7b1-361ac950a39d	4000-EDGE-COMPUTE-REV	0	250000000
fcba3be5-b293-4ea6-8fbd-ef806a1c8540	dc10482a-54f3-41dd-811d-737ea696cd06	1000-VPP-EDGE-CLEARING	250000000	0
bd2c021f-7c53-4948-ab25-8bb4ba511e24	dc10482a-54f3-41dd-811d-737ea696cd06	4000-EDGE-COMPUTE-REV	0	250000000
7292de9b-d0e1-4e79-8a96-9a2aa0930cda	6b8b01cd-41f7-4312-86b7-a9c60c495412	1000-VPP-EDGE-CLEARING	250000000	0
6fddb1dc-477e-4a67-94f6-6940cac8c779	6b8b01cd-41f7-4312-86b7-a9c60c495412	4000-EDGE-COMPUTE-REV	0	250000000
0a9be727-55e9-4575-aea2-1f1161588fa2	08f8d00c-bac0-4c28-a096-00af3e56c557	1000-VPP-EDGE-CLEARING	250000000	0
2d52f784-0f35-48a2-b1ef-b80921302900	08f8d00c-bac0-4c28-a096-00af3e56c557	4000-EDGE-COMPUTE-REV	0	250000000
826b3063-40b3-45ab-b6bd-9d7332bbc418	840f220e-7234-4a82-b220-d6b1d026a25e	1000-VPP-EDGE-CLEARING	250000000	0
9df947b1-bd3a-4506-be9c-f8986cc5aa72	840f220e-7234-4a82-b220-d6b1d026a25e	4000-EDGE-COMPUTE-REV	0	250000000
33b4feb8-7cd4-457c-91fe-bd60753d7d9e	ca949cb3-2f9a-4af8-b47d-8f9214eadae5	1000-VPP-EDGE-CLEARING	250000000	0
363c1787-1992-4ade-910d-5dc1d0713b3b	ca949cb3-2f9a-4af8-b47d-8f9214eadae5	4000-EDGE-COMPUTE-REV	0	250000000
e3f0359d-c0e4-4cf1-80de-d0a148e10df8	dbbbd490-bb6d-4381-9a50-e070ba03d7a1	1000-VPP-EDGE-CLEARING	250000000	0
4b45fd17-964a-4919-9674-b6fe00cab123	dbbbd490-bb6d-4381-9a50-e070ba03d7a1	4000-EDGE-COMPUTE-REV	0	250000000
77ee11ea-782c-4e0b-93fd-be3bcc6efb28	82dcc7db-ee81-4423-91e5-1af2259d1e5d	1000-VPP-EDGE-CLEARING	250000000	0
22488e15-9480-446c-8213-4b2fcd792409	82dcc7db-ee81-4423-91e5-1af2259d1e5d	4000-EDGE-COMPUTE-REV	0	250000000
f7fc6c3c-c0ca-497b-b83a-6e28700ac8a4	31eeb524-c892-4181-a14e-ca3b2f17a7c5	1000-VPP-EDGE-CLEARING	250000000	0
f2a24eb6-0824-4c33-bcef-63710d91fb85	31eeb524-c892-4181-a14e-ca3b2f17a7c5	4000-EDGE-COMPUTE-REV	0	250000000
0feb1c5f-5435-43e0-aada-e8f9dc4bc562	b2ab42b9-59f9-48ec-a722-d94fdb8c05d9	1000-VPP-EDGE-CLEARING	250000000	0
13d11488-fa8f-42cd-ad2d-8670be1d653a	b2ab42b9-59f9-48ec-a722-d94fdb8c05d9	4000-EDGE-COMPUTE-REV	0	250000000
34a5546b-77b6-45e3-9d2a-e41e4f30dc9a	e4f1d90e-f97e-4f48-a2af-c632dbad6ab3	1000-VPP-EDGE-CLEARING	250000000	0
a945cc05-5f4d-47b1-ac4e-802d9e11698c	e4f1d90e-f97e-4f48-a2af-c632dbad6ab3	4000-EDGE-COMPUTE-REV	0	250000000
34348791-708a-4f5e-bbb9-784af74f982f	79771330-4c4c-4a04-8218-b12a55809221	1000-VPP-EDGE-CLEARING	250000000	0
f3587606-bbf0-4833-88fa-8845b201ef17	79771330-4c4c-4a04-8218-b12a55809221	4000-EDGE-COMPUTE-REV	0	250000000
00784500-f3d2-420a-b914-4626318907e8	e7d38853-f8aa-4800-ae66-06ad75a0b779	1000-VPP-EDGE-CLEARING	250000000	0
4aee6010-6615-4a80-b550-436141014dff	e7d38853-f8aa-4800-ae66-06ad75a0b779	4000-EDGE-COMPUTE-REV	0	250000000
bb98e370-3472-46f0-acbe-07378fad2fe8	88b96c52-f892-41f0-a7e3-4c7961bec217	1000-VPP-EDGE-CLEARING	250000000	0
a3041e48-fa58-45c4-8bad-163fa75d2e89	88b96c52-f892-41f0-a7e3-4c7961bec217	4000-EDGE-COMPUTE-REV	0	250000000
2f5353ca-cdbe-4259-865b-eedc007c31c1	35dac487-1668-423d-8a20-a3d14eaf4bf4	1000-VPP-EDGE-CLEARING	250000000	0
21b132fa-1a5d-40b7-8732-add728d0ab64	35dac487-1668-423d-8a20-a3d14eaf4bf4	4000-EDGE-COMPUTE-REV	0	250000000
4f376545-ee0a-4225-9dee-4f6ecfde46fa	7ad59f05-0902-4351-a3b8-10ac3bef28dc	1000-VPP-EDGE-CLEARING	250000000	0
fcc1be83-55f2-4118-bd29-248fef8904f5	7ad59f05-0902-4351-a3b8-10ac3bef28dc	4000-EDGE-COMPUTE-REV	0	250000000
1bafbdac-9a2d-423d-ada6-3ffb9a4cd0f9	0cbb4a98-b23b-4399-9cd4-6c6267a0e6a4	1000-VPP-EDGE-CLEARING	250000000	0
db456b21-8882-49d3-a692-cc9bcadf3f7b	0cbb4a98-b23b-4399-9cd4-6c6267a0e6a4	4000-EDGE-COMPUTE-REV	0	250000000
caa0e823-8151-4f02-a5c3-1417e999a14e	0a7fe9f5-1f26-49d4-88b8-9d0a473fddda	1000-VPP-EDGE-CLEARING	250000000	0
69eec6dd-9cd8-44eb-a1db-c4616071fb17	0a7fe9f5-1f26-49d4-88b8-9d0a473fddda	4000-EDGE-COMPUTE-REV	0	250000000
07f077a7-0ed3-4a16-96b4-b302880078e4	1d29a24e-8f4c-402c-b443-c61a8c20bfe2	1000-VPP-EDGE-CLEARING	250000000	0
b40a7673-1b26-4129-9102-0357089a7219	1d29a24e-8f4c-402c-b443-c61a8c20bfe2	4000-EDGE-COMPUTE-REV	0	250000000
5aa2a6c3-19dd-4429-a49f-19c5ca2e48de	9485bdee-9f55-4af7-b2eb-a7b606465c6a	1000-VPP-EDGE-CLEARING	250000000	0
be576fc3-2a5f-4f1d-9e9a-2f117c8b5ae9	9485bdee-9f55-4af7-b2eb-a7b606465c6a	4000-EDGE-COMPUTE-REV	0	250000000
4a8e2fe1-956f-4027-a68e-5a01e3fe0231	d4cab496-6003-46ec-8adb-fffff85e0bf6	1000-VPP-EDGE-CLEARING	250000000	0
f6192a7e-02df-4719-bf37-ccd3734af6be	d4cab496-6003-46ec-8adb-fffff85e0bf6	4000-EDGE-COMPUTE-REV	0	250000000
e661c8c7-3f07-45f0-97ef-01a136cfd1a9	697a510a-1f48-4fb4-a6a9-d88f4b7aec00	1000-VPP-EDGE-CLEARING	250000000	0
35472a55-3385-4f02-b511-d6451a7a2268	697a510a-1f48-4fb4-a6a9-d88f4b7aec00	4000-EDGE-COMPUTE-REV	0	250000000
8d7498a0-d6b2-4f68-a124-13543aa88c9e	fbcd5032-0d44-4224-a21f-d58d26970368	1000-VPP-EDGE-CLEARING	250000000	0
23fcd53b-2467-4922-a594-f37b7487beb8	fbcd5032-0d44-4224-a21f-d58d26970368	4000-EDGE-COMPUTE-REV	0	250000000
ae3136d7-accd-4887-b359-54ccd2b80122	5c35028e-7747-408e-9505-c19edbd0b585	1000-VPP-EDGE-CLEARING	250000000	0
58227bf1-920e-452c-a766-84832a5587ed	5c35028e-7747-408e-9505-c19edbd0b585	4000-EDGE-COMPUTE-REV	0	250000000
7aa37848-ea0b-4b26-85dd-15b67a263207	4249eb47-46f3-4f79-b181-8991e457a8fd	1000-VPP-EDGE-CLEARING	250000000	0
a3f947d1-c3b5-4c7b-b9c8-b0ed5ff9f1aa	4249eb47-46f3-4f79-b181-8991e457a8fd	4000-EDGE-COMPUTE-REV	0	250000000
ebc56718-6a2e-4fd4-8206-5563915e5f7c	9ba7cfc2-c65b-4e60-9738-93bb9d2428ce	1000-VPP-EDGE-CLEARING	250000000	0
ed36f52d-8e19-416c-8b34-4b3788bf4f3f	9ba7cfc2-c65b-4e60-9738-93bb9d2428ce	4000-EDGE-COMPUTE-REV	0	250000000
7474fd4b-02ce-4cb7-82b0-5504cac90970	c912d065-0cc7-4c7b-90a8-e225698622bd	1000-VPP-EDGE-CLEARING	250000000	0
713d2426-d699-47c2-8183-caf462867980	c912d065-0cc7-4c7b-90a8-e225698622bd	4000-EDGE-COMPUTE-REV	0	250000000
530e31c0-7d3b-46f9-958b-0d05aecdabe5	7c5ccc06-a312-4ecc-90eb-5828720a7dd7	1000-VPP-EDGE-CLEARING	250000000	0
e22453d4-ce88-45a2-917f-6be87910ad01	7c5ccc06-a312-4ecc-90eb-5828720a7dd7	4000-EDGE-COMPUTE-REV	0	250000000
525a4338-37a8-41b3-883c-efece1d94eb9	56e18bcb-f9c2-47ff-8e46-03eee91ab3fa	1000-VPP-EDGE-CLEARING	250000000	0
1037197b-90b1-499f-8492-d85560d1c48b	56e18bcb-f9c2-47ff-8e46-03eee91ab3fa	4000-EDGE-COMPUTE-REV	0	250000000
39d5a8bb-95ed-41e0-bc1a-44158b0e7107	d2e27296-79ee-4772-b2ed-aa981d3e96ac	1000-VPP-EDGE-CLEARING	250000000	0
9fd3ab78-5d6e-437d-8362-a63089e0156b	d2e27296-79ee-4772-b2ed-aa981d3e96ac	4000-EDGE-COMPUTE-REV	0	250000000
cda03d03-76aa-437b-866f-800731df8d9a	63ca6dea-7eaa-4edc-8f2f-4885c9a54f71	1000-VPP-EDGE-CLEARING	250000000	0
339f56cf-8784-45d5-af4c-5625cdadb94e	63ca6dea-7eaa-4edc-8f2f-4885c9a54f71	4000-EDGE-COMPUTE-REV	0	250000000
354fc496-e1e1-4f04-83e0-1dcaecd543bb	8d7e2d99-be65-4d1f-b53a-ad75712e0453	1000-VPP-EDGE-CLEARING	250000000	0
7b5eefbb-9e44-4840-a1a3-dbc9673b2338	8d7e2d99-be65-4d1f-b53a-ad75712e0453	4000-EDGE-COMPUTE-REV	0	250000000
db1c9434-1731-4d87-ac17-95e6d7fd4f8a	f2086d4d-1fe8-48d8-8b5e-e0e47d9517b8	1000-VPP-EDGE-CLEARING	250000000	0
f94caade-628e-4124-931b-1d7e37d92702	f2086d4d-1fe8-48d8-8b5e-e0e47d9517b8	4000-EDGE-COMPUTE-REV	0	250000000
18174ddf-f306-4bf7-b903-03036595899c	048b4bdd-d5cc-483d-9073-bf79cb01aff3	1000-VPP-EDGE-CLEARING	250000000	0
dd94496a-6f09-4c15-8d5d-038fa03a099e	048b4bdd-d5cc-483d-9073-bf79cb01aff3	4000-EDGE-COMPUTE-REV	0	250000000
cd5f6a58-8df6-4376-b61b-72047c8ec984	23dc980d-8b60-4d56-bd97-c05ad8906c71	1000-VPP-EDGE-CLEARING	250000000	0
c7acce7a-a667-4c3d-aad6-d79c215c9aae	23dc980d-8b60-4d56-bd97-c05ad8906c71	4000-EDGE-COMPUTE-REV	0	250000000
e435d70d-b1c7-41f3-8474-21c44a373a8e	e653b691-d8ef-4794-97ae-261b780f9a2c	1000-VPP-EDGE-CLEARING	250000000	0
2e6491fd-7b26-4c49-8e27-2b26b0530dce	e653b691-d8ef-4794-97ae-261b780f9a2c	4000-EDGE-COMPUTE-REV	0	250000000
5dd32cf0-c7e7-450c-9e95-0af22d7ea927	67dd6151-fe59-4e26-af39-edd94381f030	1000-VPP-EDGE-CLEARING	250000000	0
c95e84ce-8ee5-4d5e-abcc-563346e79350	67dd6151-fe59-4e26-af39-edd94381f030	4000-EDGE-COMPUTE-REV	0	250000000
b6fc4df2-bd3f-4de0-b95e-1fd6e4f34ab8	8f967e3c-6596-4732-855e-1c23f64019cc	1000-VPP-EDGE-CLEARING	250000000	0
5424a07b-1c56-45b4-95d5-f5b4582e769f	8f967e3c-6596-4732-855e-1c23f64019cc	4000-EDGE-COMPUTE-REV	0	250000000
b25ff05c-8dd4-4fa6-bd6e-ec60c9fd8041	f8b1c0bd-9f7a-46e0-a4ae-b9f0cbaa455a	1000-VPP-EDGE-CLEARING	250000000	0
604ef43e-86ba-4c0a-a039-6ef92874a87d	f8b1c0bd-9f7a-46e0-a4ae-b9f0cbaa455a	4000-EDGE-COMPUTE-REV	0	250000000
a7fd0f37-7907-4ae3-ad70-0acdeae05724	13cb7be3-3928-4dcd-907f-b463a4d776d0	1000-VPP-EDGE-CLEARING	250000000	0
d9910c7a-e570-4bf2-9024-a29ae2f7da71	13cb7be3-3928-4dcd-907f-b463a4d776d0	4000-EDGE-COMPUTE-REV	0	250000000
75129f67-cc71-4349-88ca-2f8d8140b2e1	60af2f00-588b-4720-909a-8da33f732b43	1000-VPP-EDGE-CLEARING	250000000	0
030aee57-0bdc-46bf-8840-e6c2e9f5a01f	60af2f00-588b-4720-909a-8da33f732b43	4000-EDGE-COMPUTE-REV	0	250000000
33c0026a-0d7f-4f4a-85b0-abf22ef1f518	0a9f7ab5-4cf2-4590-a3cf-4539e4928265	1000-VPP-EDGE-CLEARING	250000000	0
316c40d7-7cea-4dce-a55a-24efa31c0233	0a9f7ab5-4cf2-4590-a3cf-4539e4928265	4000-EDGE-COMPUTE-REV	0	250000000
81d81d1d-38f6-4124-b780-b8ce4540ce40	02b9ea79-f8ba-4f52-81b8-662bce9c1d59	1000-VPP-EDGE-CLEARING	250000000	0
21125dfc-f3bf-4178-8726-460be4118c3d	02b9ea79-f8ba-4f52-81b8-662bce9c1d59	4000-EDGE-COMPUTE-REV	0	250000000
c745fb43-6010-419a-8ee7-2bc8f33dc31b	be5bad9f-7b5b-484d-8976-d9d4dbd8b54b	1000-VPP-EDGE-CLEARING	250000000	0
e65d10e6-eac8-4762-ad72-b80217e74558	be5bad9f-7b5b-484d-8976-d9d4dbd8b54b	4000-EDGE-COMPUTE-REV	0	250000000
3e2d2e88-abbc-426b-86ea-b605f8617b9f	91dd9985-c38e-4b4d-a7ce-fd3682d593a8	1000-VPP-EDGE-CLEARING	250000000	0
71cfceec-0164-4908-8bc4-a2cc16a3e6a8	91dd9985-c38e-4b4d-a7ce-fd3682d593a8	4000-EDGE-COMPUTE-REV	0	250000000
8bbe2bb7-5c00-451f-b6d0-c593d2ee8162	89a00b9f-ba72-4872-9652-8bcd48ecfc68	1000-VPP-EDGE-CLEARING	250000000	0
c7213329-9222-4e00-9246-c9a697f673ec	89a00b9f-ba72-4872-9652-8bcd48ecfc68	4000-EDGE-COMPUTE-REV	0	250000000
bbd1782f-c0c5-4f5f-81d5-f45b041661c2	3c2cd0db-1262-496b-ad9e-8f144ed2d57b	1000-VPP-EDGE-CLEARING	250000000	0
ce495baa-ba34-404c-b06c-c2292413ca6f	3c2cd0db-1262-496b-ad9e-8f144ed2d57b	4000-EDGE-COMPUTE-REV	0	250000000
8db66637-ddf4-4b72-a75f-0e8219026e91	524de706-2679-4739-bac8-f47fa3371ec6	1000-VPP-EDGE-CLEARING	250000000	0
6c580b60-2e94-4c52-98ba-6db90e6006e4	524de706-2679-4739-bac8-f47fa3371ec6	4000-EDGE-COMPUTE-REV	0	250000000
a58d9f92-78ee-4e2a-9dc8-babe59dac8af	6b7dbd39-ed85-4213-ace4-c51deb88bc99	1000-VPP-EDGE-CLEARING	250000000	0
f05c3994-4e7e-471b-b2cd-116b10351628	6b7dbd39-ed85-4213-ace4-c51deb88bc99	4000-EDGE-COMPUTE-REV	0	250000000
b1acc1c9-029b-4439-b70d-5081882df83d	6e38c6c2-09de-49fe-80e5-6a743b4acad2	1000-VPP-EDGE-CLEARING	250000000	0
fe461abd-554d-4eac-8f7e-ffe85410e956	6e38c6c2-09de-49fe-80e5-6a743b4acad2	4000-EDGE-COMPUTE-REV	0	250000000
f43d2f07-528b-44fa-958e-179f6f56499d	72e7b489-e8f3-4848-b042-ff8d1c6397ed	1000-VPP-EDGE-CLEARING	250000000	0
7ee24672-3dd7-4f9b-83c0-49d06fd73302	72e7b489-e8f3-4848-b042-ff8d1c6397ed	4000-EDGE-COMPUTE-REV	0	250000000
31e2b3c5-c370-45cc-9191-c2d2e67c926a	d472117a-9de1-4341-8d5b-0d452fd2e658	1000-VPP-EDGE-CLEARING	250000000	0
a9aa3a89-d0d0-4ece-acff-67d3bd047d34	d472117a-9de1-4341-8d5b-0d452fd2e658	4000-EDGE-COMPUTE-REV	0	250000000
4114551a-062c-41d3-889d-044cd8b98767	ca0e86fd-1a27-4a11-ab32-f7ced6b819a2	1000-VPP-EDGE-CLEARING	250000000	0
330aa70a-c177-48d2-80c0-2e5e4baff748	ca0e86fd-1a27-4a11-ab32-f7ced6b819a2	4000-EDGE-COMPUTE-REV	0	250000000
cfed9503-348b-4bc8-8fca-0931556faf8b	dc5c1574-851f-4310-a098-20a4b458275d	1000-VPP-EDGE-CLEARING	250000000	0
4c6872fb-63de-41a4-8440-4ee3c291556a	dc5c1574-851f-4310-a098-20a4b458275d	4000-EDGE-COMPUTE-REV	0	250000000
c1df9d8c-6f6f-4b59-9b25-a908b43429da	29adfa16-d795-4f61-8648-523e2e43912b	1000-VPP-EDGE-CLEARING	250000000	0
b85b2a5e-f72e-477c-83f2-07a55b34857a	29adfa16-d795-4f61-8648-523e2e43912b	4000-EDGE-COMPUTE-REV	0	250000000
4d421ff9-d446-4dc9-ab44-13dfb22d3715	df8faf1d-30dd-4e05-840e-b40faf91b494	1000-VPP-EDGE-CLEARING	250000000	0
79659d0d-7c1b-41d9-9592-949d7a8c721a	df8faf1d-30dd-4e05-840e-b40faf91b494	4000-EDGE-COMPUTE-REV	0	250000000
05a90a3e-c163-4d9f-a7a6-28bb93f09913	2d96b74b-1f80-469b-9624-b0264cb1ed0b	1000-VPP-EDGE-CLEARING	250000000	0
ad430245-33b6-478f-9881-2e7c021c2f49	2d96b74b-1f80-469b-9624-b0264cb1ed0b	4000-EDGE-COMPUTE-REV	0	250000000
aef33fe7-a076-4e86-8b29-462ea2b3a74e	5e1c553f-f4ef-45ae-8726-512560875141	1000-VPP-EDGE-CLEARING	250000000	0
b03a2f6d-c6f4-48d6-a08e-c63716b42605	5e1c553f-f4ef-45ae-8726-512560875141	4000-EDGE-COMPUTE-REV	0	250000000
196be065-d3dc-4c0b-8b72-e8fc644fe597	bf7e327e-8038-462b-93c6-1ec6306e6574	1000-VPP-EDGE-CLEARING	250000000	0
b5cf1ef9-872a-4235-a475-9256fbcff0a0	bf7e327e-8038-462b-93c6-1ec6306e6574	4000-EDGE-COMPUTE-REV	0	250000000
1a5e6d4f-fd33-477e-8086-adc8b6678a9f	80c3572d-0314-4eb6-b5f1-c5475b0f9c14	1000-VPP-EDGE-CLEARING	250000000	0
e6e30265-01ac-40a3-99aa-01c69d261a5c	80c3572d-0314-4eb6-b5f1-c5475b0f9c14	4000-EDGE-COMPUTE-REV	0	250000000
751abe08-c203-47db-a15c-9cf5bc21792d	3aa8d99b-f4de-4de8-a47b-5ffa765eeea0	1000-VPP-EDGE-CLEARING	250000000	0
1464e3a2-26b1-45b5-bfce-da09f6f45af8	3aa8d99b-f4de-4de8-a47b-5ffa765eeea0	4000-EDGE-COMPUTE-REV	0	250000000
9ad97acb-425f-463f-b448-c15042c5c462	01ba641b-82d6-4835-9933-0765b283e132	1000-VPP-EDGE-CLEARING	250000000	0
9bc1c0af-6ac9-4c92-ba2b-8b1e61d18f6c	01ba641b-82d6-4835-9933-0765b283e132	4000-EDGE-COMPUTE-REV	0	250000000
59528b97-72a3-47b3-ae2e-0e58777e843a	d0d28c78-975e-48c9-a079-99ce4bfdd8f5	1000-VPP-EDGE-CLEARING	250000000	0
ed0bf457-fb91-44b1-906e-701ed9d962be	d0d28c78-975e-48c9-a079-99ce4bfdd8f5	4000-EDGE-COMPUTE-REV	0	250000000
adcf692a-d961-4d86-bfcb-775456af9e0e	b8f0b3c1-55cb-43cc-a3e6-47b9bd004b1f	1000-VPP-EDGE-CLEARING	250000000	0
c0a51ee8-2f7d-4a59-b166-99462631ce5c	b8f0b3c1-55cb-43cc-a3e6-47b9bd004b1f	4000-EDGE-COMPUTE-REV	0	250000000
3e3314b4-8350-4f55-b395-a41b1e7020eb	ba256560-e96c-4083-9c49-8854fe0a77e6	1000-VPP-EDGE-CLEARING	250000000	0
929c4a2b-6ad9-4ae3-83b3-a746716646b5	ba256560-e96c-4083-9c49-8854fe0a77e6	4000-EDGE-COMPUTE-REV	0	250000000
005a511f-1a05-4437-926a-7bd4f6c404cb	de965f80-c166-49a6-aa72-624d2514168b	1000-VPP-EDGE-CLEARING	250000000	0
59b07eab-f920-461a-8c4a-3823cd3fca51	de965f80-c166-49a6-aa72-624d2514168b	4000-EDGE-COMPUTE-REV	0	250000000
25c0526f-50cc-4423-adac-3064c0d0b5b4	3910bdea-87ce-459f-b371-d565a2a280d1	1000-VPP-EDGE-CLEARING	250000000	0
b27d6c55-be8e-44fb-a092-af43da43868d	3910bdea-87ce-459f-b371-d565a2a280d1	4000-EDGE-COMPUTE-REV	0	250000000
fcd4390b-0928-4d2d-9d14-3db7af1b7d4a	0091ac7d-b026-495c-af07-4838861c567d	1000-VPP-EDGE-CLEARING	250000000	0
2fdfdf6f-3bcb-4265-9c30-d2122a58cff4	0091ac7d-b026-495c-af07-4838861c567d	4000-EDGE-COMPUTE-REV	0	250000000
42d6486a-b817-402d-a454-53d1c9d0c3db	4688a0ac-5555-4329-a913-5443fcdcd2c2	1000-VPP-EDGE-CLEARING	250000000	0
ed94d12c-f4f4-4545-8d16-ad1fb9a20205	4688a0ac-5555-4329-a913-5443fcdcd2c2	4000-EDGE-COMPUTE-REV	0	250000000
f23bf7d7-b7bf-49a5-9399-01a8aaf353e3	a0662732-c373-460b-a7cf-70a063f228a6	1000-VPP-EDGE-CLEARING	250000000	0
048aa82b-301d-4d85-96d0-7a354b1ed898	a0662732-c373-460b-a7cf-70a063f228a6	4000-EDGE-COMPUTE-REV	0	250000000
89081147-cddb-43e6-bcae-5e1349728c65	4893246b-9b3a-4acf-a3db-536c9a9d5062	1000-VPP-EDGE-CLEARING	250000000	0
ccf28de4-2c0e-48dc-8bb0-dcd5d1491aa4	4893246b-9b3a-4acf-a3db-536c9a9d5062	4000-EDGE-COMPUTE-REV	0	250000000
8e05a662-b6d7-413a-9bfa-314ee5d4f50f	6ee9edeb-128d-40a4-bd61-834a7bc3487d	1000-VPP-EDGE-CLEARING	250000000	0
f9349c06-7216-4b50-a435-8c81a0ed19ae	6ee9edeb-128d-40a4-bd61-834a7bc3487d	4000-EDGE-COMPUTE-REV	0	250000000
137a6cbe-dc4a-4554-918c-a328fd7ec7a8	cbb13499-c1a1-4206-b08d-d8b545fd2465	1000-VPP-EDGE-CLEARING	250000000	0
0c4b33a6-36ae-4fb8-bf7a-a2558727be6b	cbb13499-c1a1-4206-b08d-d8b545fd2465	4000-EDGE-COMPUTE-REV	0	250000000
5db121e1-fc4e-43fd-bba7-8db015fc9503	1ea6dd68-f018-48e6-9dd3-01e67b821388	1000-VPP-EDGE-CLEARING	250000000	0
5c58b958-2637-4109-87ed-f6092cd6c191	1ea6dd68-f018-48e6-9dd3-01e67b821388	4000-EDGE-COMPUTE-REV	0	250000000
9796189e-6722-43f9-b24d-e4ce08b501e2	883c2682-fafa-4a64-90a8-59da566baa7a	1000-VPP-EDGE-CLEARING	250000000	0
196dabc3-aab1-4cbe-8b7b-8ed9722cdc8c	883c2682-fafa-4a64-90a8-59da566baa7a	4000-EDGE-COMPUTE-REV	0	250000000
bb30de35-9f51-4a20-83ef-d74e2a573b1f	62fd4a71-7ebd-4726-8a6a-ca2fa884349f	1000-VPP-EDGE-CLEARING	250000000	0
c150236f-3c53-45bb-a249-9733fac45bf3	62fd4a71-7ebd-4726-8a6a-ca2fa884349f	4000-EDGE-COMPUTE-REV	0	250000000
1614c5f9-5a87-4bde-a33b-4720a9bd34b0	72d9eb7c-3ba7-4bff-878f-8efcf84bce53	1000-VPP-EDGE-CLEARING	250000000	0
e7a7aae8-e478-4cb6-87c5-12403f457e74	72d9eb7c-3ba7-4bff-878f-8efcf84bce53	4000-EDGE-COMPUTE-REV	0	250000000
f5113acb-2397-42fa-8715-009d918b5cc6	e07f7f0a-7556-4b84-9276-8c3876b506c2	1000-VPP-EDGE-CLEARING	250000000	0
cc170a50-fb2f-4d17-9b3c-8b233fd78b6a	e07f7f0a-7556-4b84-9276-8c3876b506c2	4000-EDGE-COMPUTE-REV	0	250000000
\.


--
-- Data for Name: energetics_settlement_entries; Type: TABLE DATA; Schema: public; Owner: u0_a315
--

COPY public.energetics_settlement_entries (entry_id, idempotency_key, domain_id, iso_rto_node_id, dispatched_energy_uwh, lmp_price_per_mwh_micro_usd, irc_45y_ptc_micro_usd, aaufsa_sec_5000f_tax_micro_usd, aaufsa_oasdi_75_pct_micro_usd, aaufsa_reskilling_25_pct_micro_usd, aaufsa_statutory_basis, posted_at) FROM stdin;
1fa3c744-5369-4cd3-a5e6-e9ad8521464f	LOT-REVENUE-AURAINTELCORE-20261031201104	188680247367	PJM-WEST-HUB-NODE-04	250000000000000	45000000	6875000000	0	0	0	IRC Sec. 5000H(d) Technology/SaaS Safe Harbor & IRC Sec. 45Y Clean PTC Direct Monetization	2026-10-31 16:11:04.579244-04
f1a9b766-851f-40ec-be17-58a9e901b9bc	INV-AUTO-20261031201223	188680247367	PJM-WEST-HUB-NODE-04	50000000000000	45000000	1375000000	0	0	0	IRC Sec. 5000H(d) Recurring Automated SaaS Settlement	2026-10-31 16:12:23.85472-04
092cca26-4b98-4bb0-a1e3-56e1a082d61c	STRIPE-evt_live_test_001	188680247367	STRIPE-PAYMENTS-GATEWAY	0	0	0	0	0	0	IRC Sec. 5000H(d) Stripe B2B SaaS Subscription Payment	2026-10-31 16:52:36.593587-04
c9419e42-e2b7-4d6b-ae7e-96c952c98ab2	STRIPE-evt_webhook_prod_002	188680247367	STRIPE-PAYMENTS-GATEWAY	0	0	0	0	0	0	IRC Sec. 5000H(d) Stripe B2B SaaS Subscription Payment	2026-10-31 16:53:30.606805-04
dacdffda-fc51-47a7-93f2-d0043cc11bfb	INV-AUTO-20261031210001	188680247367	PJM-WEST-HUB-NODE-04	50000000000000	45000000	1375000000	0	0	0	IRC Sec. 5000H(d) Recurring Automated SaaS Settlement	2026-10-31 17:00:01.291348-04
f45518da-8d47-44fb-9101-9366beabe96c	STRIPE-test_ping	188680247367	STRIPE-PAYMENTS-GATEWAY	0	0	0	0	0	0	IRC Sec. 5000H(d) Stripe B2B SaaS Subscription Payment	2026-10-31 17:29:45.406496-04
9a29642f-9892-466e-9bb3-d8c133a85c85	STRIPE-ping_reconnect	188680247367	STRIPE-PAYMENTS-GATEWAY	0	0	0	0	0	0	IRC Sec. 5000H(d) Stripe B2B SaaS Subscription Payment	2026-10-31 17:37:48.286369-04
335fed18-e815-4835-acfb-4dabca146c6d	INV-AUTO-20261031220000	188680247367	PJM-WEST-HUB-NODE-04	50000000000000	45000000	1375000000	0	0	0	IRC Sec. 5000H(d) Recurring Automated SaaS Settlement	2026-10-31 18:00:00.836192-04
ae000277-3970-4000-8000-000000277397	INV277397-GRAFANA-CLOUD-OPEX-20261009	188680247367	PJM-WEST-HUB-NODE-04	250000000000000	45000000	6875000000	0	0	0	IRC Sec. 5000H(d) Technology/SaaS Safe Harbor & IRC Sec. 45Y Clean PTC Direct Monetization	2026-10-31 16:11:04.579244-04
cf5fa5c7-9acf-4058-a68b-4cc2afa1051b	INV-AUTO-20261031230000	188680247367	PJM-WEST-HUB-NODE-04	50000000000000	45000000	1375000000	0	0	0	IRC Sec. 5000H(d) Recurring Automated SaaS Settlement	2026-10-31 19:00:00.543599-04
5b2eb17c-4fd4-4434-881d-babef370d12d	INV-AUTO-20261101020000	188680247367	PJM-WEST-HUB-NODE-04	50000000000000	45000000	1375000000	0	0	0	IRC Sec. 5000H(d) Recurring Automated SaaS Settlement	2026-10-31 22:00:01.175429-04
e9c533f3-b488-41f9-8818-27dcb48f5fde	INV-AUTO-20261101030000	188680247367	PJM-WEST-HUB-NODE-04	50000000000000	45000000	1375000000	0	0	0	IRC Sec. 5000H(d) Recurring Automated SaaS Settlement	2026-10-31 23:00:00.358424-04
\.


--
-- Data for Name: energetics_settlement_lines; Type: TABLE DATA; Schema: public; Owner: u0_a315
--

COPY public.energetics_settlement_lines (line_id, entry_id, domain_id, account_code, debit_micro_usd, credit_micro_usd) FROM stdin;
9722896c-521b-43e5-a45a-54bbf1d19043	1fa3c744-5369-4cd3-a5e6-e9ad8521464f	188680247367	1100-RECEIVABLES-ISO-RTO-COMMERCIAL	24375000000	0
3f2a720d-5bda-4fd1-b0df-42d3962ddcb5	1fa3c744-5369-4cd3-a5e6-e9ad8521464f	188680247367	4100-REVENUE-WHOLESALE-ENERGY-LMP	0	11250000000
129a3811-6413-42a5-8a12-481ea0550745	1fa3c744-5369-4cd3-a5e6-e9ad8521464f	188680247367	4200-REVENUE-ANCILLARY-SERVICES-FFR	0	3750000000
3c797818-a3af-4a3f-8bc9-e4d147279c43	1fa3c744-5369-4cd3-a5e6-e9ad8521464f	188680247367	4300-REVENUE-CLEAN-ENERGY-CERT-RECS	0	2500000000
a82e5c96-80d8-4a04-8d3c-c6cfc62d4236	1fa3c744-5369-4cd3-a5e6-e9ad8521464f	188680247367	4400-IRC-45Y-CLEAN-POWER-TAX-CREDIT	0	6875000000
65444c50-a2cf-4330-92b0-a9c077fd2908	f1a9b766-851f-40ec-be17-58a9e901b9bc	188680247367	1100-RECEIVABLES-ISO-RTO-COMMERCIAL	4875000000	0
33344d11-72fa-4135-b01a-55c6c42d8a1e	f1a9b766-851f-40ec-be17-58a9e901b9bc	188680247367	4100-REVENUE-WHOLESALE-ENERGY-LMP	0	2250000000
2b19bcd7-b40c-4772-8e20-9a9854c2d13f	f1a9b766-851f-40ec-be17-58a9e901b9bc	188680247367	4200-REVENUE-ANCILLARY-SERVICES-FFR	0	750000000
533c94f1-955d-49ea-8986-16d26a0cd4b9	f1a9b766-851f-40ec-be17-58a9e901b9bc	188680247367	4300-REVENUE-CLEAN-ENERGY-CERT-RECS	0	500000000
ab34cfb3-289b-4e66-9b84-58b127ae4c50	f1a9b766-851f-40ec-be17-58a9e901b9bc	188680247367	4400-IRC-45Y-CLEAN-POWER-TAX-CREDIT	0	1375000000
484c393c-3d8d-4bbc-beb6-17d278da6e3a	092cca26-4b98-4bb0-a1e3-56e1a082d61c	188680247367	1010-CASH-STRIPE-OPERATING	49990000	0
1c3cc250-62d8-4268-983c-b61dc9c4d6af	092cca26-4b98-4bb0-a1e3-56e1a082d61c	188680247367	4100-REVENUE-SAAS-CORE-SUBSCRIPTION	0	49990000
994afd7d-44d3-4c20-b087-39e6bd6bf6a4	c9419e42-e2b7-4d6b-ae7e-96c952c98ab2	188680247367	1010-CASH-STRIPE-OPERATING	49990000	0
1d4eb824-49b2-4a24-9ff7-43c6cb14a61c	c9419e42-e2b7-4d6b-ae7e-96c952c98ab2	188680247367	4100-REVENUE-SAAS-CORE-SUBSCRIPTION	0	49990000
72c9b638-da1f-41f8-8ec0-e118e8f7c877	dacdffda-fc51-47a7-93f2-d0043cc11bfb	188680247367	1100-RECEIVABLES-ISO-RTO-COMMERCIAL	4875000000	0
c5072ab1-94ed-422e-acc4-dac8942eb2cf	dacdffda-fc51-47a7-93f2-d0043cc11bfb	188680247367	4100-REVENUE-WHOLESALE-ENERGY-LMP	0	2250000000
e26a9620-0848-4009-98d6-d6e87a348efa	dacdffda-fc51-47a7-93f2-d0043cc11bfb	188680247367	4200-REVENUE-ANCILLARY-SERVICES-FFR	0	750000000
52e4e2b0-da08-43e1-b23e-1d0ad140e3c7	dacdffda-fc51-47a7-93f2-d0043cc11bfb	188680247367	4300-REVENUE-CLEAN-ENERGY-CERT-RECS	0	500000000
db295786-f9f4-4d36-a73c-6f3515ae6250	dacdffda-fc51-47a7-93f2-d0043cc11bfb	188680247367	4400-IRC-45Y-CLEAN-POWER-TAX-CREDIT	0	1375000000
f34210e1-2e19-4c5f-9545-0a5151008fe7	f45518da-8d47-44fb-9101-9366beabe96c	188680247367	1010-CASH-STRIPE-OPERATING	49990000	0
8c4654a3-9548-42a3-8651-c4704fd464a1	f45518da-8d47-44fb-9101-9366beabe96c	188680247367	4100-REVENUE-SAAS-CORE-SUBSCRIPTION	0	49990000
c64175fc-ab62-47d1-99ce-737efa2c3db0	9a29642f-9892-466e-9bb3-d8c133a85c85	188680247367	1010-CASH-STRIPE-OPERATING	49990000	0
ff16b02e-586e-4f12-a89d-b8720149c55d	9a29642f-9892-466e-9bb3-d8c133a85c85	188680247367	4100-REVENUE-SAAS-CORE-SUBSCRIPTION	0	49990000
ff2834bf-5721-4a0e-8884-bf09cf7dd59a	335fed18-e815-4835-acfb-4dabca146c6d	188680247367	1100-RECEIVABLES-ISO-RTO-COMMERCIAL	4875000000	0
43deba09-1b20-4329-ba69-64a141f86808	335fed18-e815-4835-acfb-4dabca146c6d	188680247367	4100-REVENUE-WHOLESALE-ENERGY-LMP	0	2250000000
e2b34fbc-16c4-4dfa-b999-8f3aac208182	335fed18-e815-4835-acfb-4dabca146c6d	188680247367	4200-REVENUE-ANCILLARY-SERVICES-FFR	0	750000000
bbd4d0d3-7273-4ad7-8a3f-c8f6ef19bf73	335fed18-e815-4835-acfb-4dabca146c6d	188680247367	4300-REVENUE-CLEAN-ENERGY-CERT-RECS	0	500000000
7d66e9fe-5ad9-4195-b513-d4c4c098533a	335fed18-e815-4835-acfb-4dabca146c6d	188680247367	4400-IRC-45Y-CLEAN-POWER-TAX-CREDIT	0	1375000000
cf98743c-51f5-4885-b734-3ff6ba1cd31c	ae000277-3970-4000-8000-000000277397	188680247367	5100_OPEX_GRAFANA_CLOUD_INV277397	14100000	0
9b4ec4c4-8d43-4613-8d4c-e618d109b7c1	ae000277-3970-4000-8000-000000277397	188680247367	1010_CASH_SETTLEMENT_GRAFANA_INV277397	0	14100000
f9ebf9ec-3284-4c47-a9fa-6f3bb79927b3	cf5fa5c7-9acf-4058-a68b-4cc2afa1051b	188680247367	1100-RECEIVABLES-ISO-RTO-COMMERCIAL	4875000000	0
9bf1948e-0943-4150-968d-2b1897d1615e	cf5fa5c7-9acf-4058-a68b-4cc2afa1051b	188680247367	4100-REVENUE-WHOLESALE-ENERGY-LMP	0	2250000000
d027e54c-d5a4-4a5e-85b2-286bc7bf4678	cf5fa5c7-9acf-4058-a68b-4cc2afa1051b	188680247367	4200-REVENUE-ANCILLARY-SERVICES-FFR	0	750000000
9dd66554-e9c1-463a-8bfb-eb38334621b1	cf5fa5c7-9acf-4058-a68b-4cc2afa1051b	188680247367	4300-REVENUE-CLEAN-ENERGY-CERT-RECS	0	500000000
755e69eb-02cf-489e-bc61-62f59240d5a9	cf5fa5c7-9acf-4058-a68b-4cc2afa1051b	188680247367	4400-IRC-45Y-CLEAN-POWER-TAX-CREDIT	0	1375000000
686ad184-a775-4ae2-b9bd-c1e242c1b953	5b2eb17c-4fd4-4434-881d-babef370d12d	188680247367	1100-RECEIVABLES-ISO-RTO-COMMERCIAL	4875000000	0
dadca2eb-069d-43f1-a07a-5eeefa7d865f	5b2eb17c-4fd4-4434-881d-babef370d12d	188680247367	4100-REVENUE-WHOLESALE-ENERGY-LMP	0	2250000000
681b964d-2775-4c99-818d-44a235e0372c	5b2eb17c-4fd4-4434-881d-babef370d12d	188680247367	4200-REVENUE-ANCILLARY-SERVICES-FFR	0	750000000
c83fe22c-cb34-41e4-a37e-cb33ab0fdc86	5b2eb17c-4fd4-4434-881d-babef370d12d	188680247367	4300-REVENUE-CLEAN-ENERGY-CERT-RECS	0	500000000
1f226cb0-80ac-458e-8169-9065bf45ba7c	5b2eb17c-4fd4-4434-881d-babef370d12d	188680247367	4400-IRC-45Y-CLEAN-POWER-TAX-CREDIT	0	1375000000
0d25763f-4186-4529-9e96-ebe01b56f036	e9c533f3-b488-41f9-8818-27dcb48f5fde	188680247367	1100-RECEIVABLES-ISO-RTO-COMMERCIAL	4875000000	0
5b046284-132a-40f4-a40e-0fa843f5c74e	e9c533f3-b488-41f9-8818-27dcb48f5fde	188680247367	4100-REVENUE-WHOLESALE-ENERGY-LMP	0	2250000000
375a2bf7-7f9f-4a1e-8f45-67bc8961585b	e9c533f3-b488-41f9-8818-27dcb48f5fde	188680247367	4200-REVENUE-ANCILLARY-SERVICES-FFR	0	750000000
5e1f7bb0-8c09-4d2e-9129-897564172a93	e9c533f3-b488-41f9-8818-27dcb48f5fde	188680247367	4300-REVENUE-CLEAN-ENERGY-CERT-RECS	0	500000000
558632cd-b6da-4f5d-9087-15799d9964fa	e9c533f3-b488-41f9-8818-27dcb48f5fde	188680247367	4400-IRC-45Y-CLEAN-POWER-TAX-CREDIT	0	1375000000
\.


--
-- Data for Name: ledger_accounts; Type: TABLE DATA; Schema: public; Owner: u0_a315
--

COPY public.ledger_accounts (account_id, account_number, name, currency, created_at) FROM stdin;
69200e6c-1465-49df-8b80-18e2237d85bf	1000-STRIPE-CLEARING	Stripe Clearing Account	USD	2026-10-30 12:27:31.720174-04
f0a5af20-ecf2-46c9-befd-37e9996644f8	4000-SUBSCRIPTION-REV	Subscription Revenue	USD	2026-10-30 12:27:31.720174-04
95cffd36-f6e0-4b39-9c96-115cf80d46c2	4100-REFUNDS-CONTRA	Contra Revenue - Refunds	USD	2026-10-30 12:35:12.394745-04
7d9c93d6-0402-4c3d-a5a8-246695aa3d36	5000-STRIPE-PROCESSING-FEE	Stripe Processing Fee Expense	USD	2026-10-30 12:38:26.814225-04
c6223a5b-c620-46db-b5bf-dbd29b4fa5cb	4010-RECURRING-SUBSCRIPTION-REV	Recurring Subscription Revenue	USD	2026-10-30 13:43:23.757916-04
7e9b017e-8c9f-4c48-8103-8418bdd13e4c	5100-BAD-DEBT-EXPENSE	Bad Debt / Failed Payment Expense	USD	2026-10-30 13:43:23.757916-04
\.


--
-- Data for Name: ledger_entries; Type: TABLE DATA; Schema: public; Owner: u0_a315
--

COPY public.ledger_entries (entry_id, stripe_event_id, description, posted_at) FROM stdin;
7b42293e-2a62-4e52-82da-a8dfaaae437a	evt_ledger_tx_001	Stripe Event: evt_ledger_tx_001	2026-10-30 12:33:44.244149-04
ed463b62-3311-414e-81d1-6f4b36a67749	evt_refund_tx_001	Stripe Charge Refund: evt_refund_tx_001	2026-10-30 12:36:46.486738-04
0af4da51-a573-4eeb-8292-c80a350c4cb0	evt_fee_tx_002	Stripe Checkout Payment: evt_fee_tx_002	2026-10-30 12:39:52.773617-04
2d0567f5-e80c-496b-8af7-7e7c756c5e90	evt_sub_rec_003	Recurring Subscription Payment: evt_sub_rec_003	2026-10-30 13:44:55.790583-04
e8c7a05a-48ac-4454-80f7-b34ec43a028c	evt_stress_batch_5	Checkout Payment: evt_stress_batch_5	2026-10-30 13:48:24.415673-04
e43a9272-8325-411e-82e7-4e3f5952c5ea	evt_stress_batch_4	Checkout Payment: evt_stress_batch_4	2026-10-30 13:48:24.459094-04
8739ab1f-c4d0-49d3-ad1f-8877877aa1fa	evt_stress_batch_1	Checkout Payment: evt_stress_batch_1	2026-10-30 13:48:24.469621-04
a3021475-2675-4127-8a94-43bb00abc32e	evt_stress_batch_2	Checkout Payment: evt_stress_batch_2	2026-10-30 13:48:24.6908-04
a53e0c74-642e-4ec4-a227-8b64788b4ab7	evt_stress_batch_3	Checkout Payment: evt_stress_batch_3	2026-10-30 13:48:24.725791-04
\.


--
-- Data for Name: ledger_lines; Type: TABLE DATA; Schema: public; Owner: u0_a315
--

COPY public.ledger_lines (line_id, entry_id, account_id, debit_amount_cents, credit_amount_cents) FROM stdin;
24cf0c28-b06f-45ed-b8fa-86a4f401cad5	7b42293e-2a62-4e52-82da-a8dfaaae437a	69200e6c-1465-49df-8b80-18e2237d85bf	4900	0
525b4899-fd46-4137-92d5-7f8852d83b41	7b42293e-2a62-4e52-82da-a8dfaaae437a	f0a5af20-ecf2-46c9-befd-37e9996644f8	0	4900
aa5d05ef-65d7-4d4d-ac74-05ad039961e4	ed463b62-3311-414e-81d1-6f4b36a67749	95cffd36-f6e0-4b39-9c96-115cf80d46c2	2000	0
25c2d294-b744-41e8-97ff-be1b9ad72ea0	ed463b62-3311-414e-81d1-6f4b36a67749	69200e6c-1465-49df-8b80-18e2237d85bf	0	2000
43945008-33cf-4de6-8ab0-820a7ab9f265	0af4da51-a573-4eeb-8292-c80a350c4cb0	69200e6c-1465-49df-8b80-18e2237d85bf	9680	0
147ad8ce-bab6-4378-88e9-1639ebde2fe7	0af4da51-a573-4eeb-8292-c80a350c4cb0	7d9c93d6-0402-4c3d-a5a8-246695aa3d36	320	0
83b3d674-e94a-4748-998d-e6981b216cef	0af4da51-a573-4eeb-8292-c80a350c4cb0	f0a5af20-ecf2-46c9-befd-37e9996644f8	0	10000
a8c08eba-e2b5-46bd-a7e4-daedfbefabfa	2d0567f5-e80c-496b-8af7-7e7c756c5e90	69200e6c-1465-49df-8b80-18e2237d85bf	2786	0
9a3fc897-58d6-4027-8b23-70a66a8e820c	2d0567f5-e80c-496b-8af7-7e7c756c5e90	7d9c93d6-0402-4c3d-a5a8-246695aa3d36	114	0
d509c3a4-7ccc-49d6-8055-b990fdc05045	2d0567f5-e80c-496b-8af7-7e7c756c5e90	c6223a5b-c620-46db-b5bf-dbd29b4fa5cb	0	2900
5fe12882-02ba-4364-8bfe-1eaf1430102f	e8c7a05a-48ac-4454-80f7-b34ec43a028c	69200e6c-1465-49df-8b80-18e2237d85bf	4825	0
a4142366-e1fd-4c73-9534-5f1a8091157f	e8c7a05a-48ac-4454-80f7-b34ec43a028c	7d9c93d6-0402-4c3d-a5a8-246695aa3d36	175	0
a2c3fd33-4b06-4694-ab25-9b57f00f2352	e8c7a05a-48ac-4454-80f7-b34ec43a028c	f0a5af20-ecf2-46c9-befd-37e9996644f8	0	5000
30c22ed2-7a1e-4758-b5b8-d47f4fbb8815	e43a9272-8325-411e-82e7-4e3f5952c5ea	69200e6c-1465-49df-8b80-18e2237d85bf	4825	0
d9a9e8da-6b64-4913-a306-4cf07fc155ca	e43a9272-8325-411e-82e7-4e3f5952c5ea	7d9c93d6-0402-4c3d-a5a8-246695aa3d36	175	0
6e388fa7-5a57-4234-9f75-878436a23b5a	e43a9272-8325-411e-82e7-4e3f5952c5ea	f0a5af20-ecf2-46c9-befd-37e9996644f8	0	5000
3d6588e6-5cb6-4385-895e-ecc0c9a8cea6	8739ab1f-c4d0-49d3-ad1f-8877877aa1fa	69200e6c-1465-49df-8b80-18e2237d85bf	4825	0
479960b3-8f65-42fe-9795-2c7c968de722	8739ab1f-c4d0-49d3-ad1f-8877877aa1fa	7d9c93d6-0402-4c3d-a5a8-246695aa3d36	175	0
6989eb80-e398-4e8b-8686-61ec4e93782d	8739ab1f-c4d0-49d3-ad1f-8877877aa1fa	f0a5af20-ecf2-46c9-befd-37e9996644f8	0	5000
c93cb50a-091c-485c-9612-6c3db36c1c57	a3021475-2675-4127-8a94-43bb00abc32e	69200e6c-1465-49df-8b80-18e2237d85bf	4825	0
6831fa22-8af4-4f4e-835b-061fb6bd7d2e	a3021475-2675-4127-8a94-43bb00abc32e	7d9c93d6-0402-4c3d-a5a8-246695aa3d36	175	0
ae748532-8607-4fbe-9d5e-01a4242a34fe	a3021475-2675-4127-8a94-43bb00abc32e	f0a5af20-ecf2-46c9-befd-37e9996644f8	0	5000
c5934296-17df-49df-b993-883c293db708	a53e0c74-642e-4ec4-a227-8b64788b4ab7	69200e6c-1465-49df-8b80-18e2237d85bf	4825	0
089868bc-5814-4acc-b8f4-29fcf67bf72a	a53e0c74-642e-4ec4-a227-8b64788b4ab7	7d9c93d6-0402-4c3d-a5a8-246695aa3d36	175	0
18be2e34-fba1-4e52-922c-9bb5344fe2ac	a53e0c74-642e-4ec4-a227-8b64788b4ab7	f0a5af20-ecf2-46c9-befd-37e9996644f8	0	5000
\.


--
-- Data for Name: vpp_synchrophasor_dispatch_events; Type: TABLE DATA; Schema: public; Owner: u0_a315
--

COPY public.vpp_synchrophasor_dispatch_events (event_id, holding_org_id, domain_id, lifecycle_folder_id, vpp_resource_id, grid_freq_uhz, grid_voltage_micro_pu, phase_angle_diff_udeg, rocof_uhz_per_sec, ptp_time_skew_ns, dispatched_active_power_uw, dispatched_reactive_power_uvar, dispatched_energy_uwh, primary_operator_id, secondary_engineer_id, recorded_at, event_sha256) FROM stdin;
\.


--
-- Name: edge_ledger_accounts edge_ledger_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.edge_ledger_accounts
    ADD CONSTRAINT edge_ledger_accounts_pkey PRIMARY KEY (account_number);


--
-- Name: edge_ledger_entries edge_ledger_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.edge_ledger_entries
    ADD CONSTRAINT edge_ledger_entries_pkey PRIMARY KEY (entry_id);


--
-- Name: edge_ledger_lines edge_ledger_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.edge_ledger_lines
    ADD CONSTRAINT edge_ledger_lines_pkey PRIMARY KEY (line_id);


--
-- Name: energetics_settlement_entries energetics_settlement_entries_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.energetics_settlement_entries
    ADD CONSTRAINT energetics_settlement_entries_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: energetics_settlement_entries energetics_settlement_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.energetics_settlement_entries
    ADD CONSTRAINT energetics_settlement_entries_pkey PRIMARY KEY (entry_id);


--
-- Name: energetics_settlement_lines energetics_settlement_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.energetics_settlement_lines
    ADD CONSTRAINT energetics_settlement_lines_pkey PRIMARY KEY (line_id);


--
-- Name: ledger_accounts ledger_accounts_account_number_key; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.ledger_accounts
    ADD CONSTRAINT ledger_accounts_account_number_key UNIQUE (account_number);


--
-- Name: ledger_accounts ledger_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.ledger_accounts
    ADD CONSTRAINT ledger_accounts_pkey PRIMARY KEY (account_id);


--
-- Name: ledger_entries ledger_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_pkey PRIMARY KEY (entry_id);


--
-- Name: ledger_entries ledger_entries_stripe_event_id_key; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_stripe_event_id_key UNIQUE (stripe_event_id);


--
-- Name: ledger_lines ledger_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.ledger_lines
    ADD CONSTRAINT ledger_lines_pkey PRIMARY KEY (line_id);


--
-- Name: vpp_synchrophasor_dispatch_events vpp_synchrophasor_dispatch_events_pkey; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.vpp_synchrophasor_dispatch_events
    ADD CONSTRAINT vpp_synchrophasor_dispatch_events_pkey PRIMARY KEY (event_id);


--
-- Name: idx_edge_entries_domain; Type: INDEX; Schema: public; Owner: u0_a315
--

CREATE INDEX idx_edge_entries_domain ON public.edge_ledger_entries USING btree (domain_id);


--
-- Name: idx_edge_lines_entry_id; Type: INDEX; Schema: public; Owner: u0_a315
--

CREATE INDEX idx_edge_lines_entry_id ON public.edge_ledger_lines USING btree (entry_id);


--
-- Name: edge_ledger_entries rule_edge_entries_no_delete; Type: RULE; Schema: public; Owner: u0_a315
--

CREATE RULE rule_edge_entries_no_delete AS
    ON DELETE TO public.edge_ledger_entries DO INSTEAD NOTHING;


--
-- Name: edge_ledger_entries rule_edge_entries_no_update; Type: RULE; Schema: public; Owner: u0_a315
--

CREATE RULE rule_edge_entries_no_update AS
    ON UPDATE TO public.edge_ledger_entries DO INSTEAD NOTHING;


--
-- Name: edge_ledger_lines rule_edge_lines_no_delete; Type: RULE; Schema: public; Owner: u0_a315
--

CREATE RULE rule_edge_lines_no_delete AS
    ON DELETE TO public.edge_ledger_lines DO INSTEAD NOTHING;


--
-- Name: edge_ledger_lines rule_edge_lines_no_update; Type: RULE; Schema: public; Owner: u0_a315
--

CREATE RULE rule_edge_lines_no_update AS
    ON UPDATE TO public.edge_ledger_lines DO INSTEAD NOTHING;


--
-- Name: energetics_settlement_entries worm_no_delete_settlement_entries; Type: RULE; Schema: public; Owner: u0_a315
--

CREATE RULE worm_no_delete_settlement_entries AS
    ON DELETE TO public.energetics_settlement_entries DO INSTEAD NOTHING;


--
-- Name: energetics_settlement_lines worm_no_delete_settlement_lines; Type: RULE; Schema: public; Owner: u0_a315
--

CREATE RULE worm_no_delete_settlement_lines AS
    ON DELETE TO public.energetics_settlement_lines DO INSTEAD NOTHING;


--
-- Name: vpp_synchrophasor_dispatch_events worm_no_delete_vpp_events; Type: RULE; Schema: public; Owner: u0_a315
--

CREATE RULE worm_no_delete_vpp_events AS
    ON DELETE TO public.vpp_synchrophasor_dispatch_events DO INSTEAD NOTHING;


--
-- Name: energetics_settlement_entries worm_no_update_settlement_entries; Type: RULE; Schema: public; Owner: u0_a315
--

CREATE RULE worm_no_update_settlement_entries AS
    ON UPDATE TO public.energetics_settlement_entries DO INSTEAD NOTHING;


--
-- Name: energetics_settlement_lines worm_no_update_settlement_lines; Type: RULE; Schema: public; Owner: u0_a315
--

CREATE RULE worm_no_update_settlement_lines AS
    ON UPDATE TO public.energetics_settlement_lines DO INSTEAD NOTHING;


--
-- Name: vpp_synchrophasor_dispatch_events worm_no_update_vpp_events; Type: RULE; Schema: public; Owner: u0_a315
--

CREATE RULE worm_no_update_vpp_events AS
    ON UPDATE TO public.vpp_synchrophasor_dispatch_events DO INSTEAD NOTHING;


--
-- Name: ledger_lines trg_enforce_double_entry; Type: TRIGGER; Schema: public; Owner: u0_a315
--

CREATE CONSTRAINT TRIGGER trg_enforce_double_entry AFTER INSERT OR UPDATE ON public.ledger_lines DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.check_transaction_balance();


--
-- Name: energetics_settlement_lines trg_enforce_zero_balance_energetics; Type: TRIGGER; Schema: public; Owner: u0_a315
--

CREATE CONSTRAINT TRIGGER trg_enforce_zero_balance_energetics AFTER INSERT ON public.energetics_settlement_lines DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.verify_energetics_double_entry_balance();


--
-- Name: edge_ledger_lines edge_ledger_lines_account_number_fkey; Type: FK CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.edge_ledger_lines
    ADD CONSTRAINT edge_ledger_lines_account_number_fkey FOREIGN KEY (account_number) REFERENCES public.edge_ledger_accounts(account_number);


--
-- Name: edge_ledger_lines edge_ledger_lines_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.edge_ledger_lines
    ADD CONSTRAINT edge_ledger_lines_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES public.edge_ledger_entries(entry_id) ON DELETE RESTRICT;


--
-- Name: energetics_settlement_lines energetics_settlement_lines_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.energetics_settlement_lines
    ADD CONSTRAINT energetics_settlement_lines_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES public.energetics_settlement_entries(entry_id) ON DELETE RESTRICT;


--
-- Name: ledger_lines ledger_lines_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.ledger_lines
    ADD CONSTRAINT ledger_lines_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.ledger_accounts(account_id) ON DELETE RESTRICT;


--
-- Name: ledger_lines ledger_lines_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.ledger_lines
    ADD CONSTRAINT ledger_lines_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES public.ledger_entries(entry_id) ON DELETE RESTRICT;


--
-- Name: edge_ledger_entries; Type: ROW SECURITY; Schema: public; Owner: u0_a315
--

ALTER TABLE public.edge_ledger_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: edge_ledger_lines; Type: ROW SECURITY; Schema: public; Owner: u0_a315
--

ALTER TABLE public.edge_ledger_lines ENABLE ROW LEVEL SECURITY;

--
-- Name: energetics_settlement_entries; Type: ROW SECURITY; Schema: public; Owner: u0_a315
--

ALTER TABLE public.energetics_settlement_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: energetics_settlement_lines; Type: ROW SECURITY; Schema: public; Owner: u0_a315
--

ALTER TABLE public.energetics_settlement_lines ENABLE ROW LEVEL SECURITY;

--
-- Name: edge_ledger_entries policy_edge_entries_multidomain; Type: POLICY; Schema: public; Owner: u0_a315
--

CREATE POLICY policy_edge_entries_multidomain ON public.edge_ledger_entries USING (((domain_id)::text = ANY ((ARRAY['877771073297'::character varying, '964521086569'::character varying, '188680247367'::character varying, '1087754464927'::character varying, '282230018778'::character varying, '358233233'::character varying])::text[])));


--
-- Name: edge_ledger_lines policy_edge_lines_multidomain; Type: POLICY; Schema: public; Owner: u0_a315
--

CREATE POLICY policy_edge_lines_multidomain ON public.edge_ledger_lines USING ((entry_id IN ( SELECT edge_ledger_entries.entry_id
   FROM public.edge_ledger_entries
  WHERE ((edge_ledger_entries.domain_id)::text = ANY ((ARRAY['877771073297'::character varying, '964521086569'::character varying, '188680247367'::character varying, '1087754464927'::character varying, '282230018778'::character varying, '358233233'::character varying])::text[])))));


--
-- Name: energetics_settlement_entries rls_settlement_entries_tenant_isolation; Type: POLICY; Schema: public; Owner: u0_a315
--

CREATE POLICY rls_settlement_entries_tenant_isolation ON public.energetics_settlement_entries USING (((domain_id)::text = current_setting('app.current_domain_id'::text, true))) WITH CHECK (((domain_id)::text = current_setting('app.current_domain_id'::text, true)));


--
-- Name: energetics_settlement_lines rls_settlement_lines_tenant_isolation; Type: POLICY; Schema: public; Owner: u0_a315
--

CREATE POLICY rls_settlement_lines_tenant_isolation ON public.energetics_settlement_lines USING (((domain_id)::text = current_setting('app.current_domain_id'::text, true))) WITH CHECK (((domain_id)::text = current_setting('app.current_domain_id'::text, true)));


--
-- Name: vpp_synchrophasor_dispatch_events rls_vpp_events_tenant_isolation; Type: POLICY; Schema: public; Owner: u0_a315
--

CREATE POLICY rls_vpp_events_tenant_isolation ON public.vpp_synchrophasor_dispatch_events USING (((domain_id)::text = current_setting('app.current_domain_id'::text, true))) WITH CHECK (((domain_id)::text = current_setting('app.current_domain_id'::text, true)));


--
-- Name: vpp_synchrophasor_dispatch_events; Type: ROW SECURITY; Schema: public; Owner: u0_a315
--

ALTER TABLE public.vpp_synchrophasor_dispatch_events ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict 94mWxOT9nCODOk3cizpLuR8q3RoxaRfnfRbopzMHW6PJluwxN2BqJAXdNX6jKoN

--
-- Database "auraintel_vpp" dump
--

--
-- PostgreSQL database dump
--

\restrict 4fUAULNAj67Xh3yg9vXDDbSpRSfeLnZOO7oVBeAqn1q99f3pdIKIxoeyLbsMwUS

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auraintel_vpp; Type: DATABASE; Schema: -; Owner: u0_a315
--

CREATE DATABASE auraintel_vpp WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE auraintel_vpp OWNER TO u0_a315;

\unrestrict 4fUAULNAj67Xh3yg9vXDDbSpRSfeLnZOO7oVBeAqn1q99f3pdIKIxoeyLbsMwUS
\connect auraintel_vpp
\restrict 4fUAULNAj67Xh3yg9vXDDbSpRSfeLnZOO7oVBeAqn1q99f3pdIKIxoeyLbsMwUS

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: prevent_ledger_tampering(); Type: FUNCTION; Schema: public; Owner: u0_a315
--

CREATE FUNCTION public.prevent_ledger_tampering() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE EXCEPTION 'OPERACION_PROHIBIDA: Libro mayor inmutable (NIST AU-9 / Materialidad Fiscal).';
END;
$$;


ALTER FUNCTION public.prevent_ledger_tampering() OWNER TO u0_a315;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: der_registered_nodes; Type: TABLE; Schema: public; Owner: u0_a315
--

CREATE TABLE public.der_registered_nodes (
    node_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    owner_legal_name character varying(255) NOT NULL,
    tax_entity_id character varying(64) NOT NULL,
    tax_regime_code character varying(16) NOT NULL,
    jurisdiction character varying(32) NOT NULL,
    iso_substation_node character varying(64) NOT NULL,
    ieee1547_cert_hash character(64) NOT NULL,
    ul1741sb_cert_hash character(64) NOT NULL,
    mtls_client_cert_fingerprint character(64) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT der_registered_nodes_jurisdiction_check CHECK (((jurisdiction)::text = ANY ((ARRAY['UsFercIso'::character varying, 'MxCenaceMem'::character varying, 'EuEnstoE'::character varying])::text[])))
);


ALTER TABLE public.der_registered_nodes OWNER TO u0_a315;

--
-- Name: vpp_dispatch_settlement_ledger; Type: TABLE; Schema: public; Owner: u0_a315
--

CREATE TABLE public.vpp_dispatch_settlement_ledger (
    record_id uuid NOT NULL,
    node_id uuid NOT NULL,
    tax_entity_id character varying(64) NOT NULL,
    jurisdiction character varying(32) NOT NULL,
    dispatched_wh bigint NOT NULL,
    gross_settlement_micro_usd bigint CONSTRAINT vpp_dispatch_settlement_led_gross_settlement_micro_usd_not_null NOT NULL,
    tax_withholding_micro_usd bigint CONSTRAINT vpp_dispatch_settlement_ledg_tax_withholding_micro_usd_not_null NOT NULL,
    net_payout_micro_usd bigint NOT NULL,
    cfdi_uuid_or_1099_ref character varying(64),
    timestamp_utc timestamp with time zone NOT NULL,
    previous_record_hash character(64) NOT NULL,
    record_hash character(64) NOT NULL,
    hmac_signature character(64) NOT NULL,
    CONSTRAINT vpp_dispatch_settlement_ledger_dispatched_wh_check CHECK ((dispatched_wh > 0)),
    CONSTRAINT vpp_dispatch_settlement_ledger_gross_settlement_micro_usd_check CHECK ((gross_settlement_micro_usd >= 0)),
    CONSTRAINT vpp_dispatch_settlement_ledger_net_payout_micro_usd_check CHECK ((net_payout_micro_usd >= 0)),
    CONSTRAINT vpp_dispatch_settlement_ledger_tax_withholding_micro_usd_check CHECK ((tax_withholding_micro_usd >= 0))
);


ALTER TABLE public.vpp_dispatch_settlement_ledger OWNER TO u0_a315;

--
-- Data for Name: der_registered_nodes; Type: TABLE DATA; Schema: public; Owner: u0_a315
--

COPY public.der_registered_nodes (node_id, owner_legal_name, tax_entity_id, tax_regime_code, jurisdiction, iso_substation_node, ieee1547_cert_hash, ul1741sb_cert_hash, mtls_client_cert_fingerprint, is_active, created_at) FROM stdin;
a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	SUNSHINE SOLAR STORAGE HOLDINGS LLC	99-8765432	W9-LLC	UsFercIso	FL-ORLANDO-SUB-01	e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855	8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4	2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae	t	2026-10-28 10:09:18.163086-04
b1eebc99-9c0b-4ef8-bb6d-6bb9bd380a22	ENERGIA DISTRIBUIDA DEL BAJIO SAPI DE CV	EDB210514AB9	601	MxCenaceMem	MX-CENACE-QRO-01	e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855	8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4	9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08	t	2026-10-28 10:18:53.803024-04
\.


--
-- Data for Name: vpp_dispatch_settlement_ledger; Type: TABLE DATA; Schema: public; Owner: u0_a315
--

COPY public.vpp_dispatch_settlement_ledger (record_id, node_id, tax_entity_id, jurisdiction, dispatched_wh, gross_settlement_micro_usd, tax_withholding_micro_usd, net_payout_micro_usd, cfdi_uuid_or_1099_ref, timestamp_utc, previous_record_hash, record_hash, hmac_signature) FROM stdin;
c1eebc99-9c0b-4ef8-bb6d-6bb9bd380a33	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	99-8765432	UsFercIso	22500000	2700000000	0	2700000000	\N	2026-10-28 10:18:53.840933-04	0000000000000000000000000000000000000000000000000000000000000000	aa0a44917ae51e71a6744add557eb5302802d5a9a712d656089e42910cf5df5a	778ecc1748dd12bbfd80199aad56c4db7924e62d38791d8dec45df1be23b6e98
d2eebc99-9c0b-4ef8-bb6d-6bb9bd380a44	b1eebc99-9c0b-4ef8-bb6d-6bb9bd380a22	EDB210514AB9	MxCenaceMem	15000000	35000000000	5600000000	40600000000	\N	2026-10-28 10:18:53.856294-04	aa0a44917ae51e71a6744add557eb5302802d5a9a712d656089e42910cf5df5a	84d036a16d56419df536b0ed4c4eefae0094062e1a9e609790785f5de482f569	d9ecea5bcee39e136531dae195b97d2b35a4877b83b7835757c9722acd97308a
\.


--
-- Name: der_registered_nodes der_registered_nodes_mtls_client_cert_fingerprint_key; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.der_registered_nodes
    ADD CONSTRAINT der_registered_nodes_mtls_client_cert_fingerprint_key UNIQUE (mtls_client_cert_fingerprint);


--
-- Name: der_registered_nodes der_registered_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.der_registered_nodes
    ADD CONSTRAINT der_registered_nodes_pkey PRIMARY KEY (node_id);


--
-- Name: vpp_dispatch_settlement_ledger vpp_dispatch_settlement_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.vpp_dispatch_settlement_ledger
    ADD CONSTRAINT vpp_dispatch_settlement_ledger_pkey PRIMARY KEY (record_id);


--
-- Name: vpp_dispatch_settlement_ledger vpp_dispatch_settlement_ledger_record_hash_key; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.vpp_dispatch_settlement_ledger
    ADD CONSTRAINT vpp_dispatch_settlement_ledger_record_hash_key UNIQUE (record_hash);


--
-- Name: vpp_dispatch_settlement_ledger trg_immutable_vpp_ledger; Type: TRIGGER; Schema: public; Owner: u0_a315
--

CREATE TRIGGER trg_immutable_vpp_ledger BEFORE DELETE OR UPDATE OR TRUNCATE ON public.vpp_dispatch_settlement_ledger FOR EACH STATEMENT EXECUTE FUNCTION public.prevent_ledger_tampering();


--
-- Name: vpp_dispatch_settlement_ledger vpp_dispatch_settlement_ledger_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.vpp_dispatch_settlement_ledger
    ADD CONSTRAINT vpp_dispatch_settlement_ledger_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.der_registered_nodes(node_id);


--
-- PostgreSQL database dump complete
--

\unrestrict 4fUAULNAj67Xh3yg9vXDDbSpRSfeLnZOO7oVBeAqn1q99f3pdIKIxoeyLbsMwUS

--
-- Database "cybernetic_ledger" dump
--

--
-- PostgreSQL database dump
--

\restrict dfWeEyVFTnhvaaDaZmu26uDh0pbfjTWuXSAXJjWPzrMLb5ap1bBPV5agnS0ZkRB

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: cybernetic_ledger; Type: DATABASE; Schema: -; Owner: u0_a315
--

CREATE DATABASE cybernetic_ledger WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE cybernetic_ledger OWNER TO u0_a315;

\unrestrict dfWeEyVFTnhvaaDaZmu26uDh0pbfjTWuXSAXJjWPzrMLb5ap1bBPV5agnS0ZkRB
\connect cybernetic_ledger
\restrict dfWeEyVFTnhvaaDaZmu26uDh0pbfjTWuXSAXJjWPzrMLb5ap1bBPV5agnS0ZkRB

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: enforce_append_only_ledger(); Type: FUNCTION; Schema: public; Owner: u0_a315
--

CREATE FUNCTION public.enforce_append_only_ledger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE EXCEPTION 'VIOLACION FORENSE: El libro mayor es estrictamente inmutable (Append-Only). Operacion % rechazada.', TG_OP;
END;
$$;


ALTER FUNCTION public.enforce_append_only_ledger() OWNER TO u0_a315;

--
-- Name: verify_double_entry_balance(); Type: FUNCTION; Schema: public; Owner: u0_a315
--

CREATE FUNCTION public.verify_double_entry_balance() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    total_debit NUMERIC;
    total_credit NUMERIC;
BEGIN
    SELECT COALESCE(SUM(debit_micro), 0), COALESCE(SUM(credit_micro), 0)
    INTO total_debit, total_credit
    FROM sovereign_journal_lines
    WHERE tx_id = NEW.tx_id AND jurisdiction_iso = NEW.jurisdiction_iso;

    IF total_debit = 0 OR total_debit <> total_credit THEN
        RAISE EXCEPTION 'VIOLACION CONTABLE: Partida doble desbalanceada para tx_id %. Debe: %, Haber: %',
            NEW.tx_id, total_debit, total_credit;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.verify_double_entry_balance() OWNER TO u0_a315;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cyber_node_registry; Type: TABLE; Schema: public; Owner: u0_a315
--

CREATE TABLE public.cyber_node_registry (
    spiffe_id text NOT NULL,
    jurisdiction_iso character(2) NOT NULL,
    hardware_sbom_sha256 character(64) NOT NULL,
    cfaa_consent_signature text NOT NULL,
    pqc_suite text DEFAULT 'X25519MLKEM768'::text NOT NULL,
    registered_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT cyber_node_registry_cfaa_consent_signature_check CHECK ((length(cfaa_consent_signature) >= 64)),
    CONSTRAINT cyber_node_registry_jurisdiction_iso_check CHECK ((jurisdiction_iso = ANY (ARRAY['MX'::bpchar, 'US'::bpchar, 'ES'::bpchar, 'DE'::bpchar, 'FR'::bpchar]))),
    CONSTRAINT cyber_node_registry_spiffe_id_check CHECK ((spiffe_id ~~ 'spiffe://prod.cybernetic.global/%'::text))
);


ALTER TABLE public.cyber_node_registry OWNER TO u0_a315;

--
-- Name: sovereign_journal_headers; Type: TABLE; Schema: public; Owner: u0_a315
--

CREATE TABLE public.sovereign_journal_headers (
    tx_id uuid NOT NULL,
    jurisdiction_iso character(2) NOT NULL,
    spiffe_id text NOT NULL,
    fiscal_standard text NOT NULL,
    digital_seal_xml_hash character(64) NOT NULL,
    previous_block_hash character(64) NOT NULL,
    current_block_hash character(64) NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
)
PARTITION BY LIST (jurisdiction_iso);


ALTER TABLE public.sovereign_journal_headers OWNER TO u0_a315;

--
-- Name: sovereign_journal_eu; Type: TABLE; Schema: public; Owner: u0_a315
--

CREATE TABLE public.sovereign_journal_eu (
    tx_id uuid CONSTRAINT sovereign_journal_headers_tx_id_not_null NOT NULL,
    jurisdiction_iso character(2) CONSTRAINT sovereign_journal_headers_jurisdiction_iso_not_null NOT NULL,
    spiffe_id text CONSTRAINT sovereign_journal_headers_spiffe_id_not_null NOT NULL,
    fiscal_standard text CONSTRAINT sovereign_journal_headers_fiscal_standard_not_null NOT NULL,
    digital_seal_xml_hash character(64) CONSTRAINT sovereign_journal_headers_digital_seal_xml_hash_not_null NOT NULL,
    previous_block_hash character(64) CONSTRAINT sovereign_journal_headers_previous_block_hash_not_null NOT NULL,
    current_block_hash character(64) CONSTRAINT sovereign_journal_headers_current_block_hash_not_null NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() CONSTRAINT sovereign_journal_headers_created_at_not_null NOT NULL
);


ALTER TABLE public.sovereign_journal_eu OWNER TO u0_a315;

--
-- Name: sovereign_journal_lines; Type: TABLE; Schema: public; Owner: u0_a315
--

CREATE TABLE public.sovereign_journal_lines (
    line_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tx_id uuid NOT NULL,
    jurisdiction_iso character(2) NOT NULL,
    account_code text NOT NULL,
    debit_micro bigint DEFAULT 0 NOT NULL,
    credit_micro bigint DEFAULT 0 NOT NULL,
    CONSTRAINT sovereign_journal_lines_check CHECK ((((debit_micro > 0) AND (credit_micro = 0)) OR ((credit_micro > 0) AND (debit_micro = 0)))),
    CONSTRAINT sovereign_journal_lines_credit_micro_check CHECK ((credit_micro >= 0)),
    CONSTRAINT sovereign_journal_lines_debit_micro_check CHECK ((debit_micro >= 0))
);


ALTER TABLE public.sovereign_journal_lines OWNER TO u0_a315;

--
-- Name: sovereign_journal_mx; Type: TABLE; Schema: public; Owner: u0_a315
--

CREATE TABLE public.sovereign_journal_mx (
    tx_id uuid CONSTRAINT sovereign_journal_headers_tx_id_not_null NOT NULL,
    jurisdiction_iso character(2) CONSTRAINT sovereign_journal_headers_jurisdiction_iso_not_null NOT NULL,
    spiffe_id text CONSTRAINT sovereign_journal_headers_spiffe_id_not_null NOT NULL,
    fiscal_standard text CONSTRAINT sovereign_journal_headers_fiscal_standard_not_null NOT NULL,
    digital_seal_xml_hash character(64) CONSTRAINT sovereign_journal_headers_digital_seal_xml_hash_not_null NOT NULL,
    previous_block_hash character(64) CONSTRAINT sovereign_journal_headers_previous_block_hash_not_null NOT NULL,
    current_block_hash character(64) CONSTRAINT sovereign_journal_headers_current_block_hash_not_null NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() CONSTRAINT sovereign_journal_headers_created_at_not_null NOT NULL
);


ALTER TABLE public.sovereign_journal_mx OWNER TO u0_a315;

--
-- Name: sovereign_journal_us; Type: TABLE; Schema: public; Owner: u0_a315
--

CREATE TABLE public.sovereign_journal_us (
    tx_id uuid CONSTRAINT sovereign_journal_headers_tx_id_not_null NOT NULL,
    jurisdiction_iso character(2) CONSTRAINT sovereign_journal_headers_jurisdiction_iso_not_null NOT NULL,
    spiffe_id text CONSTRAINT sovereign_journal_headers_spiffe_id_not_null NOT NULL,
    fiscal_standard text CONSTRAINT sovereign_journal_headers_fiscal_standard_not_null NOT NULL,
    digital_seal_xml_hash character(64) CONSTRAINT sovereign_journal_headers_digital_seal_xml_hash_not_null NOT NULL,
    previous_block_hash character(64) CONSTRAINT sovereign_journal_headers_previous_block_hash_not_null NOT NULL,
    current_block_hash character(64) CONSTRAINT sovereign_journal_headers_current_block_hash_not_null NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() CONSTRAINT sovereign_journal_headers_created_at_not_null NOT NULL
);


ALTER TABLE public.sovereign_journal_us OWNER TO u0_a315;

--
-- Name: sovereign_journal_eu; Type: TABLE ATTACH; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.sovereign_journal_headers ATTACH PARTITION public.sovereign_journal_eu FOR VALUES IN ('ES', 'DE', 'FR');


--
-- Name: sovereign_journal_mx; Type: TABLE ATTACH; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.sovereign_journal_headers ATTACH PARTITION public.sovereign_journal_mx FOR VALUES IN ('MX');


--
-- Name: sovereign_journal_us; Type: TABLE ATTACH; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.sovereign_journal_headers ATTACH PARTITION public.sovereign_journal_us FOR VALUES IN ('US');


--
-- Data for Name: cyber_node_registry; Type: TABLE DATA; Schema: public; Owner: u0_a315
--

COPY public.cyber_node_registry (spiffe_id, jurisdiction_iso, hardware_sbom_sha256, cfaa_consent_signature, pqc_suite, registered_at) FROM stdin;
spiffe://prod.cybernetic.global/ns/vpp-ot/node-001	MX	e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855	a8f5f167f44f4964e6c998dee827110c89d2f1582b2e91f167f44f4964e6c998	X25519MLKEM768	2026-10-28 13:37:25.937811-04
\.


--
-- Data for Name: sovereign_journal_eu; Type: TABLE DATA; Schema: public; Owner: u0_a315
--

COPY public.sovereign_journal_eu (tx_id, jurisdiction_iso, spiffe_id, fiscal_standard, digital_seal_xml_hash, previous_block_hash, current_block_hash, created_at) FROM stdin;
\.


--
-- Data for Name: sovereign_journal_lines; Type: TABLE DATA; Schema: public; Owner: u0_a315
--

COPY public.sovereign_journal_lines (line_id, tx_id, jurisdiction_iso, account_code, debit_micro, credit_micro) FROM stdin;
000ad2a1-6f2d-4b82-822c-c616bc3b284d	01a18391-07ca-7789-b170-fd874c6b95dc	MX	1101-CUENTAS-POR-COBRAR-CLIENTES	435000000000	0
785a8d69-13ee-4394-912a-620c5b7a2945	01a18391-07ca-7789-b170-fd874c6b95dc	MX	4101-INGRESOS-DESPACHO-ENERGIA-COMPUTO	0	375000000000
d8085a53-93ee-4a86-84f3-99e7b010d1c1	01a18391-07ca-7789-b170-fd874c6b95dc	MX	2105-IVA-TRASLADADO-POR-PAGAR	0	60000000000
d0840a3a-bf1c-4167-9155-851a3f60d594	01a18391-07ca-7789-b170-fd874c6b95dc	MX	5401-GASTO-IMPUESTO-MINIMO-GLOBAL-BEPS-P2	11250000000	0
ef886cbf-8102-4b72-8a2e-64042eab43db	01a18391-07ca-7789-b170-fd874c6b95dc	MX	2109-PROVISION-BEPS-PILAR2-POR-PAGAR	0	11250000000
0689ad3d-bf6a-4e3a-8e08-4b746e7f9dff	d633e1dc-64f8-47cc-9327-281104a1037c	MX	1101-CUENTAS-POR-COBRAR-CLIENTES	435000000000	0
bd6cfc70-4b2c-4fde-b04a-cfdadb0dd8bd	d633e1dc-64f8-47cc-9327-281104a1037c	MX	4101-INGRESOS-DESPACHO-ENERGIA-COMPUTO	0	375000000000
63d3eb40-7f52-4957-81f8-f2773421cd6a	d633e1dc-64f8-47cc-9327-281104a1037c	MX	2105-IVA-TRASLADADO-POR-PAGAR	0	60000000000
9c0745ca-0e73-42fa-8f92-ab253c122eb2	d633e1dc-64f8-47cc-9327-281104a1037c	MX	5401-GASTO-IMPUESTO-MINIMO-GLOBAL-BEPS-P2	11250000000	0
63a989ce-3aa8-4031-8550-5ad207375d70	d633e1dc-64f8-47cc-9327-281104a1037c	MX	2109-PROVISION-BEPS-PILAR2-POR-PAGAR	0	11250000000
\.


--
-- Data for Name: sovereign_journal_mx; Type: TABLE DATA; Schema: public; Owner: u0_a315
--

COPY public.sovereign_journal_mx (tx_id, jurisdiction_iso, spiffe_id, fiscal_standard, digital_seal_xml_hash, previous_block_hash, current_block_hash, created_at) FROM stdin;
01a18391-07ca-7789-b170-fd874c6b95dc	MX	spiffe://prod.cybernetic.global/ns/vpp-ot/node-001	SAT_CFDI_4.0_XML	2deb9fa49560d8027f427a7fa9ee0c730e28a0fe83e848f11613ee3963c0ab59	0000000000000000000000000000000000000000000000000000000000000000	616f6caaf4ed22b2e3fc3f0031bf3501553f30dc45f843e021a5f9d2299cca74	2026-10-28 13:37:25.939126-04
d633e1dc-64f8-47cc-9327-281104a1037c	MX	spiffe://prod.cybernetic.global/ns/vpp-ot/node-001	SAT_CFDI_4.0_XML	13f42b1ff4044b7980a09ba889318ae86fd6d8ce3c4e9f86c65a2876b59f6887	616f6caaf4ed22b2e3fc3f0031bf3501553f30dc45f843e021a5f9d2299cca74	760a780cc6296298b7486e516429451f55c548ee1b608f9914e498848ac4796a	2026-10-28 14:08:11.545143-04
\.


--
-- Data for Name: sovereign_journal_us; Type: TABLE DATA; Schema: public; Owner: u0_a315
--

COPY public.sovereign_journal_us (tx_id, jurisdiction_iso, spiffe_id, fiscal_standard, digital_seal_xml_hash, previous_block_hash, current_block_hash, created_at) FROM stdin;
\.


--
-- Name: cyber_node_registry cyber_node_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.cyber_node_registry
    ADD CONSTRAINT cyber_node_registry_pkey PRIMARY KEY (spiffe_id);


--
-- Name: sovereign_journal_headers sovereign_journal_headers_current_block_hash_jurisdiction_i_key; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.sovereign_journal_headers
    ADD CONSTRAINT sovereign_journal_headers_current_block_hash_jurisdiction_i_key UNIQUE (current_block_hash, jurisdiction_iso);


--
-- Name: sovereign_journal_eu sovereign_journal_eu_current_block_hash_jurisdiction_iso_key; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.sovereign_journal_eu
    ADD CONSTRAINT sovereign_journal_eu_current_block_hash_jurisdiction_iso_key UNIQUE (current_block_hash, jurisdiction_iso);


--
-- Name: sovereign_journal_headers sovereign_journal_headers_pkey; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.sovereign_journal_headers
    ADD CONSTRAINT sovereign_journal_headers_pkey PRIMARY KEY (tx_id, jurisdiction_iso);


--
-- Name: sovereign_journal_eu sovereign_journal_eu_pkey; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.sovereign_journal_eu
    ADD CONSTRAINT sovereign_journal_eu_pkey PRIMARY KEY (tx_id, jurisdiction_iso);


--
-- Name: sovereign_journal_lines sovereign_journal_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.sovereign_journal_lines
    ADD CONSTRAINT sovereign_journal_lines_pkey PRIMARY KEY (line_id);


--
-- Name: sovereign_journal_mx sovereign_journal_mx_current_block_hash_jurisdiction_iso_key; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.sovereign_journal_mx
    ADD CONSTRAINT sovereign_journal_mx_current_block_hash_jurisdiction_iso_key UNIQUE (current_block_hash, jurisdiction_iso);


--
-- Name: sovereign_journal_mx sovereign_journal_mx_pkey; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.sovereign_journal_mx
    ADD CONSTRAINT sovereign_journal_mx_pkey PRIMARY KEY (tx_id, jurisdiction_iso);


--
-- Name: sovereign_journal_us sovereign_journal_us_current_block_hash_jurisdiction_iso_key; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.sovereign_journal_us
    ADD CONSTRAINT sovereign_journal_us_current_block_hash_jurisdiction_iso_key UNIQUE (current_block_hash, jurisdiction_iso);


--
-- Name: sovereign_journal_us sovereign_journal_us_pkey; Type: CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.sovereign_journal_us
    ADD CONSTRAINT sovereign_journal_us_pkey PRIMARY KEY (tx_id, jurisdiction_iso);


--
-- Name: sovereign_journal_eu_current_block_hash_jurisdiction_iso_key; Type: INDEX ATTACH; Schema: public; Owner: u0_a315
--

ALTER INDEX public.sovereign_journal_headers_current_block_hash_jurisdiction_i_key ATTACH PARTITION public.sovereign_journal_eu_current_block_hash_jurisdiction_iso_key;


--
-- Name: sovereign_journal_eu_pkey; Type: INDEX ATTACH; Schema: public; Owner: u0_a315
--

ALTER INDEX public.sovereign_journal_headers_pkey ATTACH PARTITION public.sovereign_journal_eu_pkey;


--
-- Name: sovereign_journal_mx_current_block_hash_jurisdiction_iso_key; Type: INDEX ATTACH; Schema: public; Owner: u0_a315
--

ALTER INDEX public.sovereign_journal_headers_current_block_hash_jurisdiction_i_key ATTACH PARTITION public.sovereign_journal_mx_current_block_hash_jurisdiction_iso_key;


--
-- Name: sovereign_journal_mx_pkey; Type: INDEX ATTACH; Schema: public; Owner: u0_a315
--

ALTER INDEX public.sovereign_journal_headers_pkey ATTACH PARTITION public.sovereign_journal_mx_pkey;


--
-- Name: sovereign_journal_us_current_block_hash_jurisdiction_iso_key; Type: INDEX ATTACH; Schema: public; Owner: u0_a315
--

ALTER INDEX public.sovereign_journal_headers_current_block_hash_jurisdiction_i_key ATTACH PARTITION public.sovereign_journal_us_current_block_hash_jurisdiction_iso_key;


--
-- Name: sovereign_journal_us_pkey; Type: INDEX ATTACH; Schema: public; Owner: u0_a315
--

ALTER INDEX public.sovereign_journal_headers_pkey ATTACH PARTITION public.sovereign_journal_us_pkey;


--
-- Name: sovereign_journal_lines trg_check_double_entry; Type: TRIGGER; Schema: public; Owner: u0_a315
--

CREATE CONSTRAINT TRIGGER trg_check_double_entry AFTER INSERT ON public.sovereign_journal_lines DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.verify_double_entry_balance();


--
-- Name: sovereign_journal_headers trg_immutable_headers; Type: TRIGGER; Schema: public; Owner: u0_a315
--

CREATE TRIGGER trg_immutable_headers BEFORE DELETE OR UPDATE ON public.sovereign_journal_headers FOR EACH ROW EXECUTE FUNCTION public.enforce_append_only_ledger();


--
-- Name: sovereign_journal_lines trg_immutable_lines; Type: TRIGGER; Schema: public; Owner: u0_a315
--

CREATE TRIGGER trg_immutable_lines BEFORE DELETE OR UPDATE ON public.sovereign_journal_lines FOR EACH ROW EXECUTE FUNCTION public.enforce_append_only_ledger();


--
-- Name: sovereign_journal_headers sovereign_journal_headers_spiffe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE public.sovereign_journal_headers
    ADD CONSTRAINT sovereign_journal_headers_spiffe_id_fkey FOREIGN KEY (spiffe_id) REFERENCES public.cyber_node_registry(spiffe_id);


--
-- Name: sovereign_journal_lines sovereign_journal_lines_tx_id_jurisdiction_iso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: u0_a315
--

ALTER TABLE ONLY public.sovereign_journal_lines
    ADD CONSTRAINT sovereign_journal_lines_tx_id_jurisdiction_iso_fkey FOREIGN KEY (tx_id, jurisdiction_iso) REFERENCES public.sovereign_journal_headers(tx_id, jurisdiction_iso) ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict dfWeEyVFTnhvaaDaZmu26uDh0pbfjTWuXSAXJjWPzrMLb5ap1bBPV5agnS0ZkRB

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict tEuJVL1dazW4PReybhAWLmSS4zeXQWRmx77dNTZgWPVfSNNkz49efw5pGmB6eeY

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict tEuJVL1dazW4PReybhAWLmSS4zeXQWRmx77dNTZgWPVfSNNkz49efw5pGmB6eeY

--
-- Database "secure_ledger" dump
--

--
-- PostgreSQL database dump
--

\restrict BzKN5pRO3m1UR067bwMa03nplunZLRghGpvy0NWdHEnaI5miz2Qm22gsw8geCL9

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: secure_ledger; Type: DATABASE; Schema: -; Owner: u0_a315
--

CREATE DATABASE secure_ledger WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE secure_ledger OWNER TO u0_a315;

\unrestrict BzKN5pRO3m1UR067bwMa03nplunZLRghGpvy0NWdHEnaI5miz2Qm22gsw8geCL9
\connect secure_ledger
\restrict BzKN5pRO3m1UR067bwMa03nplunZLRghGpvy0NWdHEnaI5miz2Qm22gsw8geCL9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;


--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: entry_direction; Type: TYPE; Schema: public; Owner: test_user
--

CREATE TYPE public.entry_direction AS ENUM (
    'DEBIT',
    'CREDIT'
);


ALTER TYPE public.entry_direction OWNER TO test_user;

--
-- Name: verify_journal_entry_balance(); Type: FUNCTION; Schema: public; Owner: test_user
--

CREATE FUNCTION public.verify_journal_entry_balance() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_balance BIGINT;
    v_entry_id UUID;
BEGIN
    IF TG_OP = 'DELETE' THEN
        v_entry_id := OLD.journal_entry_id;
    ELSE
        v_entry_id := NEW.journal_entry_id;
    END IF;

    SELECT COALESCE(
        SUM(
            CASE 
                WHEN direction = 'DEBIT' THEN amount_cents 
                WHEN direction = 'CREDIT' THEN -amount_cents 
            END
        ), 0)
    INTO v_balance
    FROM ledger_lines
    WHERE journal_entry_id = v_entry_id;

    IF v_balance <> 0 THEN
        RAISE EXCEPTION 'Desbalance contable en el asiento %: suma neta es % centavos (debe ser 0)',
            v_entry_id, v_balance
            USING ERRCODE = 'check_violation';
    END IF;

    RETURN NULL;
END;
$$;


ALTER FUNCTION public.verify_journal_entry_balance() OWNER TO test_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounting_periods; Type: TABLE; Schema: public; Owner: test_user
--

CREATE TABLE public.accounting_periods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    period_name character varying(64) NOT NULL,
    validity_window tstzrange NOT NULL,
    is_closed boolean DEFAULT false NOT NULL
);


ALTER TABLE public.accounting_periods OWNER TO test_user;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: test_user
--

CREATE TABLE public.accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    account_number character varying(32) NOT NULL,
    name character varying(128) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


ALTER TABLE public.accounts OWNER TO test_user;

--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: test_user
--

CREATE TABLE public.journal_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    transaction_code character varying(64) NOT NULL,
    description text NOT NULL,
    posted_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    is_posted boolean DEFAULT true NOT NULL
);


ALTER TABLE public.journal_entries OWNER TO test_user;

--
-- Name: ledger_lines; Type: TABLE; Schema: public; Owner: test_user
--

CREATE TABLE public.ledger_lines (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    journal_entry_id uuid NOT NULL,
    account_id uuid NOT NULL,
    direction public.entry_direction NOT NULL,
    amount_cents bigint NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT ledger_lines_amount_cents_check CHECK ((amount_cents > 0))
);


ALTER TABLE public.ledger_lines OWNER TO test_user;

--
-- Data for Name: accounting_periods; Type: TABLE DATA; Schema: public; Owner: test_user
--

COPY public.accounting_periods (id, tenant_id, period_name, validity_window, is_closed) FROM stdin;
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: test_user
--

COPY public.accounts (id, tenant_id, account_number, name, currency, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: test_user
--

COPY public.journal_entries (id, tenant_id, transaction_code, description, posted_at, is_posted) FROM stdin;
\.


--
-- Data for Name: ledger_lines; Type: TABLE DATA; Schema: public; Owner: test_user
--

COPY public.ledger_lines (id, journal_entry_id, account_id, direction, amount_cents, created_at) FROM stdin;
\.


--
-- Name: accounting_periods accounting_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: test_user
--

ALTER TABLE ONLY public.accounting_periods
    ADD CONSTRAINT accounting_periods_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: test_user
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: accounting_periods excl_overlapping_periods; Type: CONSTRAINT; Schema: public; Owner: test_user
--

ALTER TABLE ONLY public.accounting_periods
    ADD CONSTRAINT excl_overlapping_periods EXCLUDE USING gist (tenant_id WITH =, validity_window WITH &&);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: test_user
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_transaction_code_key; Type: CONSTRAINT; Schema: public; Owner: test_user
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_transaction_code_key UNIQUE (transaction_code);


--
-- Name: ledger_lines ledger_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: test_user
--

ALTER TABLE ONLY public.ledger_lines
    ADD CONSTRAINT ledger_lines_pkey PRIMARY KEY (id);


--
-- Name: accounts uq_tenant_account; Type: CONSTRAINT; Schema: public; Owner: test_user
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT uq_tenant_account UNIQUE (tenant_id, account_number);


--
-- Name: idx_ledger_lines_account; Type: INDEX; Schema: public; Owner: test_user
--

CREATE INDEX idx_ledger_lines_account ON public.ledger_lines USING btree (account_id);


--
-- Name: idx_ledger_lines_entry; Type: INDEX; Schema: public; Owner: test_user
--

CREATE INDEX idx_ledger_lines_entry ON public.ledger_lines USING btree (journal_entry_id);


--
-- Name: ledger_lines trg_enforce_double_entry_balance; Type: TRIGGER; Schema: public; Owner: test_user
--

CREATE CONSTRAINT TRIGGER trg_enforce_double_entry_balance AFTER INSERT OR DELETE OR UPDATE ON public.ledger_lines DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.verify_journal_entry_balance();


--
-- Name: ledger_lines ledger_lines_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: test_user
--

ALTER TABLE ONLY public.ledger_lines
    ADD CONSTRAINT ledger_lines_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE RESTRICT;


--
-- Name: ledger_lines ledger_lines_journal_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: test_user
--

ALTER TABLE ONLY public.ledger_lines
    ADD CONSTRAINT ledger_lines_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES public.journal_entries(id) ON DELETE RESTRICT;


--
-- Name: accounting_periods; Type: ROW SECURITY; Schema: public; Owner: test_user
--

ALTER TABLE public.accounting_periods ENABLE ROW LEVEL SECURITY;

--
-- Name: accounts; Type: ROW SECURITY; Schema: public; Owner: test_user
--

ALTER TABLE public.accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: journal_entries; Type: ROW SECURITY; Schema: public; Owner: test_user
--

ALTER TABLE public.journal_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: ledger_lines; Type: ROW SECURITY; Schema: public; Owner: test_user
--

ALTER TABLE public.ledger_lines ENABLE ROW LEVEL SECURITY;

--
-- Name: accounts tenant_isolation_accounts; Type: POLICY; Schema: public; Owner: test_user
--

CREATE POLICY tenant_isolation_accounts ON public.accounts USING ((tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid));


--
-- Name: journal_entries tenant_isolation_journal; Type: POLICY; Schema: public; Owner: test_user
--

CREATE POLICY tenant_isolation_journal ON public.journal_entries USING ((tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid));


--
-- Name: ledger_lines tenant_isolation_lines; Type: POLICY; Schema: public; Owner: test_user
--

CREATE POLICY tenant_isolation_lines ON public.ledger_lines USING ((journal_entry_id IN ( SELECT journal_entries.id
   FROM public.journal_entries
  WHERE (journal_entries.tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid))));


--
-- Name: accounting_periods tenant_isolation_periods; Type: POLICY; Schema: public; Owner: test_user
--

CREATE POLICY tenant_isolation_periods ON public.accounting_periods USING ((tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid));


--
-- Name: DATABASE secure_ledger; Type: ACL; Schema: -; Owner: u0_a315
--

GRANT ALL ON DATABASE secure_ledger TO test_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO test_user;


--
-- PostgreSQL database dump complete
--

\unrestrict BzKN5pRO3m1UR067bwMa03nplunZLRghGpvy0NWdHEnaI5miz2Qm22gsw8geCL9

--
-- Database "sos_ledger_db" dump
--

--
-- PostgreSQL database dump
--

\restrict PGer8HvJ1cWCGQvTlq1jq7RTCIcBZc8zbYCmoGwuwIL4G9TKIAfCzonm5qvWCEG

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: sos_ledger_db; Type: DATABASE; Schema: -; Owner: u0_a315
--

CREATE DATABASE sos_ledger_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE sos_ledger_db OWNER TO u0_a315;

\unrestrict PGer8HvJ1cWCGQvTlq1jq7RTCIcBZc8zbYCmoGwuwIL4G9TKIAfCzonm5qvWCEG
\connect sos_ledger_db
\restrict PGer8HvJ1cWCGQvTlq1jq7RTCIcBZc8zbYCmoGwuwIL4G9TKIAfCzonm5qvWCEG

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: aaufsa_ledger; Type: SCHEMA; Schema: -; Owner: u0_a315
--

CREATE SCHEMA aaufsa_ledger;


ALTER SCHEMA aaufsa_ledger OWNER TO u0_a315;

--
-- Name: enforce_double_entry_balance(); Type: FUNCTION; Schema: aaufsa_ledger; Owner: u0_a315
--

CREATE FUNCTION aaufsa_ledger.enforce_double_entry_balance() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_debits  NUMERIC(20, 2);
    v_credits NUMERIC(20, 2);
BEGIN
    SELECT
        COALESCE(SUM(CASE WHEN entry_side = 'DEBIT'  THEN amount_usd ELSE 0.00 END), 0.00),
        COALESCE(SUM(CASE WHEN entry_side = 'CREDIT' THEN amount_usd ELSE 0.00 END), 0.00)
    INTO v_debits, v_credits
    FROM aaufsa_ledger.journal_lines
    WHERE journal_id = NEW.journal_id;

    IF v_debits <> v_credits THEN
        RAISE EXCEPTION 'Violación ACID Partida Doble en journal_id %: Débitos (%) != Créditos (%)',
            NEW.journal_id, v_debits, v_credits;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION aaufsa_ledger.enforce_double_entry_balance() OWNER TO u0_a315;

--
-- Name: prevent_worm_mutation(); Type: FUNCTION; Schema: aaufsa_ledger; Owner: u0_a315
--

CREATE FUNCTION aaufsa_ledger.prevent_worm_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE EXCEPTION 'Violación Forense WORM: Los registros del Plano Fiscal AAUFSA son inmutables (Operación % rechazada)', TG_OP;
END;
$$;


ALTER FUNCTION aaufsa_ledger.prevent_worm_mutation() OWNER TO u0_a315;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: controlled_group_assessments; Type: TABLE; Schema: aaufsa_ledger; Owner: u0_a315
--

CREATE TABLE aaufsa_ledger.controlled_group_assessments (
    assessment_id uuid NOT NULL,
    domain_id character varying(32) NOT NULL,
    tax_year integer NOT NULL,
    consolidated_gross_receipts_usd numeric(20,2) CONSTRAINT controlled_group_assessment_consolidated_gross_receipt_not_null NOT NULL,
    imputed_displacement_cost_usd numeric(20,2) CONSTRAINT controlled_group_assessment_imputed_displacement_cost__not_null NOT NULL,
    is_saas_vendor_exempt_sec_5000h_d boolean DEFAULT false CONSTRAINT controlled_group_assessment_is_saas_vendor_exempt_sec__not_null NOT NULL,
    safe_harbor_36m_applied_sec_5000g_a boolean DEFAULT false CONSTRAINT controlled_group_assessment_safe_harbor_36m_applied_se_not_null NOT NULL,
    clawback_triggered_sec_5000g_c boolean DEFAULT false CONSTRAINT controlled_group_assessment_clawback_triggered_sec_500_not_null NOT NULL,
    excise_tax_15_3_pct_usd numeric(20,2) NOT NULL,
    clawback_interest_usd numeric(20,2) DEFAULT 0.00 NOT NULL,
    total_chapter_56_liability_usd numeric(20,2) CONSTRAINT controlled_group_assessment_total_chapter_56_liability_not_null NOT NULL,
    oasdi_trust_75_pct_usd numeric(20,2) NOT NULL,
    reskilling_trust_25_pct_usd numeric(20,2) CONSTRAINT controlled_group_assessment_reskilling_trust_25_pct_us_not_null NOT NULL,
    recorded_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT chk_exact_liability_sum CHECK (((excise_tax_15_3_pct_usd + clawback_interest_usd) = total_chapter_56_liability_usd)),
    CONSTRAINT chk_exact_trust_fund_split CHECK (((oasdi_trust_75_pct_usd + reskilling_trust_25_pct_usd) = total_chapter_56_liability_usd)),
    CONSTRAINT controlled_group_assessments_clawback_interest_usd_check CHECK ((clawback_interest_usd >= 0.00)),
    CONSTRAINT controlled_group_assessments_consolidated_gross_receipts__check CHECK ((consolidated_gross_receipts_usd >= 0.00)),
    CONSTRAINT controlled_group_assessments_excise_tax_15_3_pct_usd_check CHECK ((excise_tax_15_3_pct_usd >= 0.00)),
    CONSTRAINT controlled_group_assessments_imputed_displacement_cost_us_check CHECK ((imputed_displacement_cost_usd >= 0.00)),
    CONSTRAINT controlled_group_assessments_oasdi_trust_75_pct_usd_check CHECK ((oasdi_trust_75_pct_usd >= 0.00)),
    CONSTRAINT controlled_group_assessments_reskilling_trust_25_pct_usd_check CHECK ((reskilling_trust_25_pct_usd >= 0.00)),
    CONSTRAINT controlled_group_assessments_tax_year_check CHECK ((tax_year >= 2026)),
    CONSTRAINT controlled_group_assessments_total_chapter_56_liability_u_check CHECK ((total_chapter_56_liability_usd >= 0.00))
);

ALTER TABLE ONLY aaufsa_ledger.controlled_group_assessments FORCE ROW LEVEL SECURITY;


ALTER TABLE aaufsa_ledger.controlled_group_assessments OWNER TO u0_a315;

--
-- Name: corporate_domains; Type: TABLE; Schema: aaufsa_ledger; Owner: u0_a315
--

CREATE TABLE aaufsa_ledger.corporate_domains (
    domain_id character varying(32) NOT NULL,
    domain_fqdn character varying(128) NOT NULL,
    org_root_id character varying(32) DEFAULT '320717657398'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT chk_org_root_id CHECK (((org_root_id)::text = '320717657398'::text)),
    CONSTRAINT chk_valid_six_domains CHECK (((domain_id)::text = ANY ((ARRAY['877771073297'::character varying, '964521086569'::character varying, '188680247367'::character varying, '1087754464927'::character varying, '282230018778'::character varying, '358233233'::character varying])::text[])))
);


ALTER TABLE aaufsa_ledger.corporate_domains OWNER TO u0_a315;

--
-- Name: journal_headers; Type: TABLE; Schema: aaufsa_ledger; Owner: u0_a315
--

CREATE TABLE aaufsa_ledger.journal_headers (
    journal_id uuid NOT NULL,
    idempotency_key character varying(128) NOT NULL,
    domain_id character varying(32) NOT NULL,
    source_plane character varying(32) NOT NULL,
    previous_merkle_hash character(64) NOT NULL,
    current_merkle_hash character(64) NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT journal_headers_source_plane_check CHECK (((source_plane)::text = 'FISCAL_PLANE_AAUFSA'::text))
);

ALTER TABLE ONLY aaufsa_ledger.journal_headers FORCE ROW LEVEL SECURITY;


ALTER TABLE aaufsa_ledger.journal_headers OWNER TO u0_a315;

--
-- Name: journal_lines; Type: TABLE; Schema: aaufsa_ledger; Owner: u0_a315
--

CREATE TABLE aaufsa_ledger.journal_lines (
    line_id bigint NOT NULL,
    journal_id uuid NOT NULL,
    domain_id character varying(32) NOT NULL,
    account_code character varying(32) NOT NULL,
    entry_side character varying(6) NOT NULL,
    amount_usd numeric(20,2) NOT NULL,
    CONSTRAINT journal_lines_amount_usd_check CHECK ((amount_usd >= 0.00)),
    CONSTRAINT journal_lines_entry_side_check CHECK (((entry_side)::text = ANY ((ARRAY['DEBIT'::character varying, 'CREDIT'::character varying])::text[])))
);

ALTER TABLE ONLY aaufsa_ledger.journal_lines FORCE ROW LEVEL SECURITY;


ALTER TABLE aaufsa_ledger.journal_lines OWNER TO u0_a315;

--
-- Name: journal_lines_line_id_seq; Type: SEQUENCE; Schema: aaufsa_ledger; Owner: u0_a315
--

CREATE SEQUENCE aaufsa_ledger.journal_lines_line_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE aaufsa_ledger.journal_lines_line_id_seq OWNER TO u0_a315;

--
-- Name: journal_lines_line_id_seq; Type: SEQUENCE OWNED BY; Schema: aaufsa_ledger; Owner: u0_a315
--

ALTER SEQUENCE aaufsa_ledger.journal_lines_line_id_seq OWNED BY aaufsa_ledger.journal_lines.line_id;


--
-- Name: journal_lines line_id; Type: DEFAULT; Schema: aaufsa_ledger; Owner: u0_a315
--

ALTER TABLE ONLY aaufsa_ledger.journal_lines ALTER COLUMN line_id SET DEFAULT nextval('aaufsa_ledger.journal_lines_line_id_seq'::regclass);


--
-- Data for Name: controlled_group_assessments; Type: TABLE DATA; Schema: aaufsa_ledger; Owner: u0_a315
--

COPY aaufsa_ledger.controlled_group_assessments (assessment_id, domain_id, tax_year, consolidated_gross_receipts_usd, imputed_displacement_cost_usd, is_saas_vendor_exempt_sec_5000h_d, safe_harbor_36m_applied_sec_5000g_a, clawback_triggered_sec_5000g_c, excise_tax_15_3_pct_usd, clawback_interest_usd, total_chapter_56_liability_usd, oasdi_trust_75_pct_usd, reskilling_trust_25_pct_usd, recorded_at) FROM stdin;
\.


--
-- Data for Name: corporate_domains; Type: TABLE DATA; Schema: aaufsa_ledger; Owner: u0_a315
--

COPY aaufsa_ledger.corporate_domains (domain_id, domain_fqdn, org_root_id, created_at) FROM stdin;
877771073297	AuraTetrax-com	320717657398	2026-10-29 13:25:00.7037-04
964521086569	Fourphonix-com	320717657398	2026-10-29 13:25:00.705525-04
188680247367	AuraIntelCore-com	320717657398	2026-10-29 13:25:00.7056-04
1087754464927	AuraIntel-Global-com	320717657398	2026-10-29 13:25:00.705625-04
282230018778	Standard1979-com	320717657398	2026-10-29 13:25:00.705643-04
358233233	Prophonix-com	320717657398	2026-10-29 13:25:00.705659-04
\.


--
-- Data for Name: journal_headers; Type: TABLE DATA; Schema: aaufsa_ledger; Owner: u0_a315
--

COPY aaufsa_ledger.journal_headers (journal_id, idempotency_key, domain_id, source_plane, previous_merkle_hash, current_merkle_hash, created_at) FROM stdin;
a0000000-0000-0000-0000-000000000001	IDEMP-2026-LIVE-001	188680247367	FISCAL_PLANE_AAUFSA	0000000000000000000000000000000000000000000000000000000000000000	e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855	2026-10-29 14:48:01.524721-04
\.


--
-- Data for Name: journal_lines; Type: TABLE DATA; Schema: aaufsa_ledger; Owner: u0_a315
--

COPY aaufsa_ledger.journal_lines (line_id, journal_id, domain_id, account_code, entry_side, amount_usd) FROM stdin;
1	a0000000-0000-0000-0000-000000000001	188680247367	6156-AAUFSA-EXP	DEBIT	153000.00
2	a0000000-0000-0000-0000-000000000001	188680247367	2156-OASDI-75	CREDIT	114750.00
3	a0000000-0000-0000-0000-000000000001	188680247367	2157-RESKILL-25	CREDIT	38250.00
\.


--
-- Name: journal_lines_line_id_seq; Type: SEQUENCE SET; Schema: aaufsa_ledger; Owner: u0_a315
--

SELECT pg_catalog.setval('aaufsa_ledger.journal_lines_line_id_seq', 3, true);


--
-- Name: controlled_group_assessments controlled_group_assessments_pkey; Type: CONSTRAINT; Schema: aaufsa_ledger; Owner: u0_a315
--

ALTER TABLE ONLY aaufsa_ledger.controlled_group_assessments
    ADD CONSTRAINT controlled_group_assessments_pkey PRIMARY KEY (assessment_id);


--
-- Name: corporate_domains corporate_domains_domain_fqdn_key; Type: CONSTRAINT; Schema: aaufsa_ledger; Owner: u0_a315
--

ALTER TABLE ONLY aaufsa_ledger.corporate_domains
    ADD CONSTRAINT corporate_domains_domain_fqdn_key UNIQUE (domain_fqdn);


--
-- Name: corporate_domains corporate_domains_pkey; Type: CONSTRAINT; Schema: aaufsa_ledger; Owner: u0_a315
--

ALTER TABLE ONLY aaufsa_ledger.corporate_domains
    ADD CONSTRAINT corporate_domains_pkey PRIMARY KEY (domain_id);


--
-- Name: journal_headers journal_headers_current_merkle_hash_key; Type: CONSTRAINT; Schema: aaufsa_ledger; Owner: u0_a315
--

ALTER TABLE ONLY aaufsa_ledger.journal_headers
    ADD CONSTRAINT journal_headers_current_merkle_hash_key UNIQUE (current_merkle_hash);


--
-- Name: journal_headers journal_headers_idempotency_key_key; Type: CONSTRAINT; Schema: aaufsa_ledger; Owner: u0_a315
--

ALTER TABLE ONLY aaufsa_ledger.journal_headers
    ADD CONSTRAINT journal_headers_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: journal_headers journal_headers_pkey; Type: CONSTRAINT; Schema: aaufsa_ledger; Owner: u0_a315
--

ALTER TABLE ONLY aaufsa_ledger.journal_headers
    ADD CONSTRAINT journal_headers_pkey PRIMARY KEY (journal_id);


--
-- Name: journal_lines journal_lines_pkey; Type: CONSTRAINT; Schema: aaufsa_ledger; Owner: u0_a315
--

ALTER TABLE ONLY aaufsa_ledger.journal_lines
    ADD CONSTRAINT journal_lines_pkey PRIMARY KEY (line_id);


--
-- Name: journal_lines trg_verify_double_entry_balance; Type: TRIGGER; Schema: aaufsa_ledger; Owner: u0_a315
--

CREATE CONSTRAINT TRIGGER trg_verify_double_entry_balance AFTER INSERT OR UPDATE ON aaufsa_ledger.journal_lines DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION aaufsa_ledger.enforce_double_entry_balance();


--
-- Name: journal_headers trg_worm_headers; Type: TRIGGER; Schema: aaufsa_ledger; Owner: u0_a315
--

CREATE TRIGGER trg_worm_headers BEFORE DELETE OR UPDATE ON aaufsa_ledger.journal_headers FOR EACH ROW EXECUTE FUNCTION aaufsa_ledger.prevent_worm_mutation();


--
-- Name: journal_lines trg_worm_lines; Type: TRIGGER; Schema: aaufsa_ledger; Owner: u0_a315
--

CREATE TRIGGER trg_worm_lines BEFORE DELETE OR UPDATE ON aaufsa_ledger.journal_lines FOR EACH ROW EXECUTE FUNCTION aaufsa_ledger.prevent_worm_mutation();


--
-- Name: controlled_group_assessments controlled_group_assessments_domain_id_fkey; Type: FK CONSTRAINT; Schema: aaufsa_ledger; Owner: u0_a315
--

ALTER TABLE ONLY aaufsa_ledger.controlled_group_assessments
    ADD CONSTRAINT controlled_group_assessments_domain_id_fkey FOREIGN KEY (domain_id) REFERENCES aaufsa_ledger.corporate_domains(domain_id);


--
-- Name: journal_headers journal_headers_domain_id_fkey; Type: FK CONSTRAINT; Schema: aaufsa_ledger; Owner: u0_a315
--

ALTER TABLE ONLY aaufsa_ledger.journal_headers
    ADD CONSTRAINT journal_headers_domain_id_fkey FOREIGN KEY (domain_id) REFERENCES aaufsa_ledger.corporate_domains(domain_id);


--
-- Name: journal_lines journal_lines_domain_id_fkey; Type: FK CONSTRAINT; Schema: aaufsa_ledger; Owner: u0_a315
--

ALTER TABLE ONLY aaufsa_ledger.journal_lines
    ADD CONSTRAINT journal_lines_domain_id_fkey FOREIGN KEY (domain_id) REFERENCES aaufsa_ledger.corporate_domains(domain_id);


--
-- Name: journal_lines journal_lines_journal_id_fkey; Type: FK CONSTRAINT; Schema: aaufsa_ledger; Owner: u0_a315
--

ALTER TABLE ONLY aaufsa_ledger.journal_lines
    ADD CONSTRAINT journal_lines_journal_id_fkey FOREIGN KEY (journal_id) REFERENCES aaufsa_ledger.journal_headers(journal_id) ON DELETE RESTRICT;


--
-- Name: controlled_group_assessments; Type: ROW SECURITY; Schema: aaufsa_ledger; Owner: u0_a315
--

ALTER TABLE aaufsa_ledger.controlled_group_assessments ENABLE ROW LEVEL SECURITY;

--
-- Name: journal_headers; Type: ROW SECURITY; Schema: aaufsa_ledger; Owner: u0_a315
--

ALTER TABLE aaufsa_ledger.journal_headers ENABLE ROW LEVEL SECURITY;

--
-- Name: journal_lines; Type: ROW SECURITY; Schema: aaufsa_ledger; Owner: u0_a315
--

ALTER TABLE aaufsa_ledger.journal_lines ENABLE ROW LEVEL SECURITY;

--
-- Name: controlled_group_assessments rls_domain_isolation_assessments; Type: POLICY; Schema: aaufsa_ledger; Owner: u0_a315
--

CREATE POLICY rls_domain_isolation_assessments ON aaufsa_ledger.controlled_group_assessments USING (((domain_id)::text = current_setting('app.current_domain_id'::text, true))) WITH CHECK (((domain_id)::text = current_setting('app.current_domain_id'::text, true)));


--
-- Name: journal_headers rls_domain_isolation_headers; Type: POLICY; Schema: aaufsa_ledger; Owner: u0_a315
--

CREATE POLICY rls_domain_isolation_headers ON aaufsa_ledger.journal_headers USING (((domain_id)::text = current_setting('app.current_domain_id'::text, true))) WITH CHECK (((domain_id)::text = current_setting('app.current_domain_id'::text, true)));


--
-- Name: journal_lines rls_domain_isolation_lines; Type: POLICY; Schema: aaufsa_ledger; Owner: u0_a315
--

CREATE POLICY rls_domain_isolation_lines ON aaufsa_ledger.journal_lines USING (((domain_id)::text = current_setting('app.current_domain_id'::text, true))) WITH CHECK (((domain_id)::text = current_setting('app.current_domain_id'::text, true)));


--
-- Name: SCHEMA aaufsa_ledger; Type: ACL; Schema: -; Owner: u0_a315
--

GRANT USAGE ON SCHEMA aaufsa_ledger TO aaufsa_app_user;


--
-- Name: TABLE controlled_group_assessments; Type: ACL; Schema: aaufsa_ledger; Owner: u0_a315
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE aaufsa_ledger.controlled_group_assessments TO aaufsa_app_user;


--
-- Name: TABLE corporate_domains; Type: ACL; Schema: aaufsa_ledger; Owner: u0_a315
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE aaufsa_ledger.corporate_domains TO aaufsa_app_user;


--
-- Name: TABLE journal_headers; Type: ACL; Schema: aaufsa_ledger; Owner: u0_a315
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE aaufsa_ledger.journal_headers TO aaufsa_app_user;


--
-- Name: TABLE journal_lines; Type: ACL; Schema: aaufsa_ledger; Owner: u0_a315
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE aaufsa_ledger.journal_lines TO aaufsa_app_user;


--
-- PostgreSQL database dump complete
--

\unrestrict PGer8HvJ1cWCGQvTlq1jq7RTCIcBZc8zbYCmoGwuwIL4G9TKIAfCzonm5qvWCEG

--
-- PostgreSQL database cluster dump complete
--

